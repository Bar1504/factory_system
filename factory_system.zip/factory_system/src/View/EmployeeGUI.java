package View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Main;

public class EmployeeGUI extends JFrame {

	private JPanel contentPane;

	public EmployeeGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 100, 950, 600);
		setVisible(true);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
	//	contentPane.add(background);
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 950, 22);
		contentPane.add(menuBar);
		menuBar.setBackground(new Color(106, 90, 205));
		
		JMenu homeMenu = new JMenu("Home");
		homeMenu.setActionCommand("Home");
		menuBar.add(homeMenu);
		
		JMenuItem homeITem = new JMenuItem("Home");
		homeITem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					dispose();
					AdminGUI adminGUIV2 = new AdminGUI();
			}
		});
		homeMenu.add(homeITem);
		
		JMenu addMenu = new JMenu("Add");
		menuBar.add(addMenu);
		
		JMenuItem carItem = new JMenuItem("Add Car");
		carItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AddCarGUI addCarGUI = new AddCarGUI(menuBar);
				setContentPane(addCarGUI);
				getContentPane().setVisible(true);
			}
		});
		addMenu.add(carItem);
		
		JMenuItem hybridCarItem = new JMenuItem("Add Hybrid Car");
		hybridCarItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AddHybridCarGUI addHybridCarGUI = new AddHybridCarGUI(menuBar);
				setContentPane(addHybridCarGUI);
				getContentPane().setVisible(true);
			}
		});
		addMenu.add(hybridCarItem);
		
		JMenuItem vanItem = new JMenuItem("Add Van");
		vanItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AddVanGUI addVanGUI = new AddVanGUI(menuBar);
				setContentPane(addVanGUI);
				getContentPane().setVisible(true);
			}
		});
		addMenu.add(vanItem);
		
		JMenuItem motorcycleItem = new JMenuItem("Add Motorcycle");
		motorcycleItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AddMotorcycleGUI addMotorcycleGUI = new AddMotorcycleGUI(menuBar);
				setContentPane(addMotorcycleGUI);
				getContentPane().setVisible(true);
			}
		});
		addMenu.add(motorcycleItem);
		
		JMenuItem hybridMotorcycleItem = new JMenuItem("Add Hybrid Motorcycle");
		hybridMotorcycleItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AddHybridMotorcycleGUI addHybridMotorcycleGUI = new AddHybridMotorcycleGUI(menuBar);
				setContentPane(addHybridMotorcycleGUI);
				getContentPane().setVisible(true);
			}
		});
		addMenu.add(hybridMotorcycleItem);
		
		JMenuItem customerItem = new JMenuItem("Add Customer");
		customerItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AddCustomerGUI addCustomerGUI = new AddCustomerGUI(menuBar);
				setContentPane(addCustomerGUI);
				getContentPane().setVisible(true);
			}
		});
		addMenu.add(customerItem);
		
		JMenuItem VIPCustomerItem = new JMenuItem("Add VIP Customer");
		VIPCustomerItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AddVIPCustomerGUI addVIPCustomerGUI = new AddVIPCustomerGUI(menuBar);
				setContentPane(addVIPCustomerGUI);
				getContentPane().setVisible(true);
			}
		});
		addMenu.add(VIPCustomerItem);
		
		JMenuItem dealItem = new JMenuItem("Add Deal");
		dealItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AddDealGUI addDealGUI = new AddDealGUI(menuBar);
				setContentPane(addDealGUI);
				getContentPane().setVisible(true);
			}
		});
		addMenu.add(dealItem);
		
		JMenuItem departmentItem = new JMenuItem("Add Department");
		departmentItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AddDepartmentGUI addDepartmentGUI = new AddDepartmentGUI(menuBar);
				setContentPane(addDepartmentGUI);
				getContentPane().setVisible(true);
			}
		});
		addMenu.add(departmentItem);
		
		JMenu removeMenu = new JMenu("Remove");
		menuBar.add(removeMenu);
		
		JMenuItem removeCarItem = new JMenuItem("Remove Car");
		removeCarItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				RemoveCarGUI removeCarGUI = new RemoveCarGUI(menuBar);
				setContentPane(removeCarGUI);
				getContentPane().setVisible(true);
			}
		});
		removeMenu.add(removeCarItem);
		
		JMenuItem removeHybridCarItem = new JMenuItem("Remove Hybrid Car");
		removeHybridCarItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				RemoveHybridCarGUI removeHybridCarGUI = new RemoveHybridCarGUI(menuBar);
				setContentPane(removeHybridCarGUI);
				getContentPane().setVisible(true);
			}
		});
		removeMenu.add(removeHybridCarItem);
		
		JMenuItem removeVanItem = new JMenuItem("Remove Van");
		removeVanItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				RemoveVanGUI removeVanGUI = new RemoveVanGUI(menuBar);
				setContentPane(removeVanGUI);
				getContentPane().setVisible(true);
			}
		});
		removeMenu.add(removeVanItem);
		
		JMenuItem removeMotoryclceItem = new JMenuItem("Remove Motorcycle");
		removeMotoryclceItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				RemoveMotorcycleGUI removeMotorcycleGUI = new RemoveMotorcycleGUI(menuBar);
				setContentPane(removeMotorcycleGUI);
				getContentPane().setVisible(true);
			}
		});
		removeMenu.add(removeMotoryclceItem);
		
		JMenuItem removeHybridMotorcycleItem = new JMenuItem("RemoveHybridMotorcycle");
		removeHybridMotorcycleItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				RemoveHybridMotorcycleGUI removeHybridMotorcycleGUI = new RemoveHybridMotorcycleGUI(menuBar);
				setContentPane(removeHybridMotorcycleGUI);
				getContentPane().setVisible(true);
			}
		});
		removeMenu.add(removeHybridMotorcycleItem);
		
		JMenuItem removeCustomerItem = new JMenuItem("Remove Customer");
		removeCustomerItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				RemoveCustomerGUI removeCustomerGUI = new RemoveCustomerGUI(menuBar);
				setContentPane(removeCustomerGUI);
				getContentPane().setVisible(true);
			}
		});
		removeMenu.add(removeCustomerItem);
		
		JMenuItem removeVIPCustomerItem = new JMenuItem("Remove VIP Customer");
		removeVIPCustomerItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				RemoveVIPCustomerGUI removeVIPCustomerGUI = new RemoveVIPCustomerGUI(menuBar);
				setContentPane(removeVIPCustomerGUI);
				getContentPane().setVisible(true);
			}
		});
		removeMenu.add(removeVIPCustomerItem);
		
		JMenuItem removeDealItem = new JMenuItem("Remove Deal");
		removeDealItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				RemoveDealGUI removeDealGUI = new RemoveDealGUI(menuBar);
				setContentPane(removeDealGUI);
				getContentPane().setVisible(true);
			}
		});
		removeMenu.add(removeDealItem);
		
		JMenu findMenu = new JMenu("Find");
		menuBar.add(findMenu);
		
		JMenuItem findCarItem = new JMenuItem("Find Car");
		findCarItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				FindCarGUI carsGUI = new FindCarGUI(menuBar);
				setContentPane(carsGUI);
				getContentPane().setVisible(true);
			}
		});
		findMenu.add(findCarItem);
		
		JMenuItem findHybridCarItem = new JMenuItem("Find Hybrid Car");
		findHybridCarItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				FindHybridCarGUI findHybridCarGUI = new FindHybridCarGUI(menuBar);
				setContentPane(findHybridCarGUI);
				getContentPane().setVisible(true);
			}
		});
		findMenu.add(findHybridCarItem);
		
		JMenuItem findVanItem = new JMenuItem("Find Van");
		findVanItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				FindVanGUI findVanGUI = new FindVanGUI(menuBar);
				setContentPane(findVanGUI);
				getContentPane().setVisible(true);
			}
		});
		findMenu.add(findVanItem);
		
		JMenuItem findMotorcycleItem = new JMenuItem("Find Motorcycle");
		findMotorcycleItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				FindMotorcycleGUI findMotorcycleGUI = new FindMotorcycleGUI(menuBar);
				setContentPane(findMotorcycleGUI);
				getContentPane().setVisible(true);
			}
		});
		findMenu.add(findMotorcycleItem);
		
		JMenuItem findHybridMotorcycleItem = new JMenuItem("Find Hybrid Motorcycle");
		findHybridMotorcycleItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				FindHybridMotorcycleGUI findHybridMotorcycleGUI = new FindHybridMotorcycleGUI(menuBar);
				setContentPane(findHybridMotorcycleGUI);
				getContentPane().setVisible(true);
			}
		});
		findMenu.add(findHybridMotorcycleItem);
		
		JMenuItem findCustomerItem = new JMenuItem("Find Customer");
		findCustomerItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				FindCustomerGUI findCustomerGUI = new FindCustomerGUI(menuBar);
				setContentPane(findCustomerGUI);
				getContentPane().setVisible(true);
			}
		});
		findMenu.add(findCustomerItem);
		
		JMenuItem findVIPCustomerItem = new JMenuItem("Find VIP Customer");
		findVIPCustomerItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				FindVIPCustomerGUI findVIPCustomerGUI = new FindVIPCustomerGUI(menuBar);
				setContentPane(findVIPCustomerGUI);
				getContentPane().setVisible(true);
			}
		});
		findMenu.add(findVIPCustomerItem);
		
		JMenuItem findEmployeeItem = new JMenuItem("Find Employee");
		findEmployeeItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				FindEmployeeGUI findEmployeeGUI = new FindEmployeeGUI(menuBar);
				setContentPane(findEmployeeGUI);
				getContentPane().setVisible(true);
			}
		});
		findMenu.add(findEmployeeItem);
		
		JMenuItem findDepartmentManagerItem = new JMenuItem("Find Department Manager");
		findDepartmentManagerItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				FindDepartmentManagerGUI findDepartmentManagerGUI = new FindDepartmentManagerGUI(menuBar);
				setContentPane(findDepartmentManagerGUI);
				getContentPane().setVisible(true);
			}
		});
		findMenu.add(findDepartmentManagerItem);
		
		JMenuItem findDealItem = new JMenuItem("Find Deal");
		findDealItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				FindDealGUI findDealGUI = new FindDealGUI(menuBar);
				setContentPane(findDealGUI);
				getContentPane().setVisible(true);
			}
		});
		findMenu.add(findDealItem);
		
		JMenuItem findDepartmentItem = new JMenuItem("Find Department");
		findDepartmentItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				FindDepartmentGUI findDepartmentGUI = new FindDepartmentGUI(menuBar);
				setContentPane(findDepartmentGUI);
				getContentPane().setVisible(true);
			}
		});
		findMenu.add(findDepartmentItem);
		
		JMenu querriesMenu = new JMenu("Querries");
		menuBar.add(querriesMenu);
		
		JMenuItem customersByAreaItem = new JMenuItem("Customers By Area");
		customersByAreaItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				CustomersByAreaGUI customersByAreaGUI = new CustomersByAreaGUI(menuBar);
				setContentPane(customersByAreaGUI);
				getContentPane().setVisible(true);
			}
		});
		querriesMenu.add(customersByAreaItem);
		
		JMenuItem peopleByGenderAndYearOfBirthItem = new JMenuItem("People By Gender And Year Of Birth");
		peopleByGenderAndYearOfBirthItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				PeopleByGenderAndYear peopleByGenderAndYear = new PeopleByGenderAndYear(menuBar);
				setContentPane(peopleByGenderAndYear);
				getContentPane().setVisible(true);
			}
		});
		querriesMenu.add(peopleByGenderAndYearOfBirthItem);
		
		JMenuItem countOfVehiclesTransportationByColorItem = new JMenuItem("Count of Vehicles By Color");
		countOfVehiclesTransportationByColorItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				VehiclesByColorGUI vehiclesByColorGUI = new VehiclesByColorGUI(menuBar);
				setContentPane(vehiclesByColorGUI);
				getContentPane().setVisible(true);
			}
		});
		querriesMenu.add(countOfVehiclesTransportationByColorItem);
		
		JMenuItem idOFDealWithMinAvgPollutionLevelItem = new JMenuItem("ID of Deal With Min Avg Pollution Level");
		idOFDealWithMinAvgPollutionLevelItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				IDOfDealWithMinAvgPollutionLevelGUI iDOfDealWithMinAvgPollutionLevelGUI = new IDOfDealWithMinAvgPollutionLevelGUI(menuBar);
				setContentPane(iDOfDealWithMinAvgPollutionLevelGUI);
				getContentPane().setVisible(true);
			}
		});
		querriesMenu.add(idOFDealWithMinAvgPollutionLevelItem);
		
		JMenuItem profitPerVehicleItem = new JMenuItem("Profit Per VehicleTransportation");
		querriesMenu.add(profitPerVehicleItem);
		
		JMenuItem totalProfitItem = new JMenuItem("Total Profit");
		querriesMenu.add(totalProfitItem);
		
		JMenuItem relativePercentageOfHybridItem = new JMenuItem("Relative Percentage Of Hybrid");
		querriesMenu.add(relativePercentageOfHybridItem);
		
		JMenuItem avgPollutionLevelOfAllVehiclesItem = new JMenuItem("Avg Pollution Level Of All Vehicles ");
		querriesMenu.add(avgPollutionLevelOfAllVehiclesItem);
		
		JMenuItem isGlobalStandardItem = new JMenuItem("Is Global Standard");
		querriesMenu.add(isGlobalStandardItem);
		
		JMenuItem vehiclesNeededItem = new JMenuItem("How Many Hybrid Vehicles Needed");
		querriesMenu.add(vehiclesNeededItem);
		
		JMenuItem appointmentOfNewDepManagerItem = new JMenuItem("Appointment Of New Dep Manager");
		appointmentOfNewDepManagerItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AppointmentOfNewDepManagerGUI appointmentOfNewDepManagerGUI = new AppointmentOfNewDepManagerGUI(menuBar);
				setContentPane(appointmentOfNewDepManagerGUI);
				getContentPane().setVisible(true);
				
			}
		});
		querriesMenu.add(appointmentOfNewDepManagerItem);
		
		JMenuItem allEmployeesItem = new JMenuItem("All Employees");
		allEmployeesItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AllEmployeesGUI allEmployeesGUI = new AllEmployeesGUI(menuBar);
				setContentPane(allEmployeesGUI);
				getContentPane().setVisible(true);
			}
		});
		querriesMenu.add(allEmployeesItem);
		
		JMenuItem allCustomersItem = new JMenuItem("All Customers");
		allCustomersItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AllCustomersGUI allCustomersGUI = new AllCustomersGUI(menuBar);
				setContentPane(allCustomersGUI);
				getContentPane().setVisible(true);
			}
		});
		querriesMenu.add(allCustomersItem);
		
		JMenuItem allVehicleTransportationItem = new JMenuItem("All Vehicles");
		allVehicleTransportationItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AllVehicleTransportationGUI allVehicleTransportationGUI = new AllVehicleTransportationGUI(menuBar);
				setContentPane(allVehicleTransportationGUI);
				getContentPane().setVisible(true);
			}
		});
		querriesMenu.add(allVehicleTransportationItem);
		
		JMenuItem allBestDepManagersItem = new JMenuItem("All Best Dep Managers");
		allBestDepManagersItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				AllBestDepManagersGUI allBestDepManagersGUI = new AllBestDepManagersGUI(menuBar);
				setContentPane(allBestDepManagersGUI);
				getContentPane().setVisible(true);
			}
		});
		querriesMenu.add(allBestDepManagersItem);
		
		JMenuItem bestDealsItem = new JMenuItem("Get Best Deals");
		bestDealsItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getContentPane().setVisible(false);
				BestDealsGUI bestDealsGUI = new BestDealsGUI(menuBar);
				setContentPane(bestDealsGUI);
				getContentPane().setVisible(true);
			}
		});
		querriesMenu.add(bestDealsItem);
		
		JMenu logOFFMenu = new JMenu("Log Off");
		menuBar.add(logOFFMenu);
		
		JMenuItem LogOffItem = new JMenuItem("Log Off");
		LogOffItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				new LoginGUI().setVisible(true);;
			}
		});
		logOFFMenu.add(LogOffItem);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 22, 950, 550);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label1 = new JLabel("HSR");
		label1.setForeground(Color.BLACK);
		label1.setBounds(45, 39, 229, 83);
		panel.add(label1);
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 70));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(37, 147, 624, 397);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("General Information");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel.setBounds(6, 6, 278, 33);
		panel_1.add(lblNewLabel);
		
		
		
		JLabel lblNewLabel_1_1 = new JLabel("Total Profit:");
		lblNewLabel_1_1.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel_1_1.setBounds(6, 120, 304, 33);
		panel_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Relative Percentage Of Hybrid Vehicles:");
		lblNewLabel_1_1_1.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel_1_1_1.setBounds(6, 170, 320, 33);
		panel_1.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Average Pollution Of all Vehicles:");
		lblNewLabel_1_1_1_1.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel_1_1_1_1.setBounds(6, 220, 392, 33);
		panel_1.add(lblNewLabel_1_1_1_1);
		
		JLabel globalLabel = new JLabel("Is Global Standard:");
		globalLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		globalLabel.setBounds(6, 270, 320, 33);
		panel_1.add(globalLabel);
		
		JLabel neededLabel = new JLabel("Relative Percentage Of Hybrid Vehicles:");
		neededLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		neededLabel.setBounds(6, 320, 320, 33);
		panel_1.add(neededLabel);
		
		
		
		JLabel profitLabel = new JLabel(String.valueOf(Main.libr.totalProfit()));
		profitLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		profitLabel.setBounds(369, 120, 179, 33);
		panel_1.add(profitLabel);
		JLabel percentageLabel = new JLabel("");

		if(Main.libr.getAllVehicleTransportation().size()>0)
			percentageLabel.setText((String.valueOf(Main.libr.relativePrecentageOfHybrid())));
		else
			percentageLabel.setText("No Vehicles In The System");
		
		percentageLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		percentageLabel.setBounds(369, 170, 249, 33);
		panel_1.add(percentageLabel);
		

		JLabel averageLabel = new JLabel("");
		if(Main.libr.getAllVehicleTransportation().size()>0)
			averageLabel.setText(String.valueOf(Main.libr.avgPollutionLevelOfAllVehiclesTransportation()));
		else
			averageLabel.setText("No Vehicles In The System");

		averageLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		averageLabel.setBounds(369, 220, 249, 33);
		panel_1.add(averageLabel);
		
		JLabel amountLabel = new JLabel(String.valueOf(Main.libr.howManyHybridVehiclesTransportationNeeded()));
		amountLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		amountLabel.setBounds(369, 320, 179, 33);
		panel_1.add(amountLabel);
		
		JLabel globalAnswerLabel = new JLabel("0.0");
		globalAnswerLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		globalAnswerLabel.setBounds(369, 265, 179, 33);
		panel_1.add(globalAnswerLabel);
		
		if(Main.libr.isGlobalStandard())
		{
			globalLabel.setText("Factory Is Global Standard");
			globalAnswerLabel.setText("Yes");
		}
		else
		{
			globalAnswerLabel.setText("No");
			neededLabel.setText("Amount of Hybrid Vehicles Needed:");
		}
	}
}
