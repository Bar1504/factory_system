package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.border.EmptyBorder;

import Exceptions.PersonNotExistException;
import model.DepartmentManager;
import model.Employee;
import model.Main;

public class RemoveDepartmentManagerGUI extends JInternalFrame {

	private JMenuBar menuBar;
	public RemoveDepartmentManagerGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		

		JLabel label1 = new JLabel("Remove Department Manager By ID");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 409, 37);
		getContentPane().add(label1);
		JComboBox<String> comboBox = new JComboBox<String>();

		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(comboBox.getSelectedIndex() ==0)
					JOptionPane.showMessageDialog(null, "Select Department Manager To Remove");
				else
				{
					int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to remove department manager from the system?", "", JOptionPane.YES_NO_OPTION);
					if (reply == JOptionPane.YES_OPTION) 
					{
						try {
							Main.libr.removeDepartmentManager((DepartmentManager) Main.libr.getAllEmployees().get(comboBox.getSelectedItem()));
							comboBox.removeAllItems();
							comboBox.addItem("Department Managers By ID:");
							for(Employee emp : Main.libr.getAllEmployees().values())
							{
								if(emp instanceof DepartmentManager)
									comboBox.addItem(emp.getID());
							}
							try {
								Main.save();
								JOptionPane.showMessageDialog(null, "Department manager removed succefully");

							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						} catch (PersonNotExistException e1) {
							JOptionPane.showMessageDialog(null, e1.getMessage());
						}
					}
				}
			}
		});
		
		btnNewButton.setBounds(753, 480, 135, 46);
		getContentPane().add(btnNewButton);

		comboBox.addItem("Department Managers By ID:");
		for(Employee emp : Main.libr.getAllEmployees().values())
		{
			if(emp instanceof DepartmentManager)
				comboBox.addItem(emp.getID());
		}
		comboBox.setBounds(50, 130, 177, 37);
		getContentPane().add(comboBox);

	}

}
