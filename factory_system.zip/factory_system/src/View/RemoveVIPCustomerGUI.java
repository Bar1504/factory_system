package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.border.EmptyBorder;

import Exceptions.PersonNotExistException;
import model.Customer;
import model.Main;
import model.VIPCustomer;

public class RemoveVIPCustomerGUI extends JInternalFrame {

	private JMenuBar menuBar;
	public RemoveVIPCustomerGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		

		JLabel label1 = new JLabel("Remove VIP Customer By ID");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 409, 37);
		getContentPane().add(label1);
		JComboBox<String> comboBox = new JComboBox<String>();

		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(comboBox.getSelectedIndex() ==0)
					JOptionPane.showMessageDialog(null, "Select VIP Customer To Remove");
				else
					try {
						Main.libr.removeVIPCustomer((VIPCustomer) Main.libr.getAllCustomers().get(comboBox.getSelectedItem()));
						comboBox.removeAllItems();
						comboBox.addItem("Customers By ID:");
						for(Customer c: Main.libr.getAllCustomers().values())
						{
							if(c instanceof VIPCustomer)
								comboBox.addItem(c.getID());
						}
						Main.save();
						JOptionPane.showMessageDialog(null, "VIP customer removed");
					} catch (PersonNotExistException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage());
					} catch (IOException e2) {
						JOptionPane.showMessageDialog(null,"There has been a problem saving the database");

					}
				
			}
		});
		
		btnNewButton.setBounds(753, 480, 135, 46);
		getContentPane().add(btnNewButton);

		comboBox.addItem("Customers By ID:");
		for(Customer c: Main.libr.getAllCustomers().values())
		{
			if(c instanceof VIPCustomer)
				comboBox.addItem(c.getID());
		}
		comboBox.setBounds(50, 130, 177, 37);
		getContentPane().add(comboBox);
	}

}
