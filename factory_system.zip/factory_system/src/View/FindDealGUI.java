package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Deal;
import model.Main;
import model.VehicleTransportation;

import javax.swing.JButton;

public class FindDealGUI extends JInternalFrame {

	private JMenuBar menuBar;
	JComboBox<String> comboBox = new JComboBox<String>();
	public FindDealGUI(JMenuBar menuBar ) {
			this.menuBar = menuBar;
			setBounds(0, 0, 950, 600);
			setBorder(new EmptyBorder(5, 5, 5, 5));

			getContentPane().add(menuBar);
			getContentPane().setLayout(null);
			
			JPanel panel1 = new JPanel();
			panel1.setBounds(465, 70, 469, 399);
			panel1.setLayout(null);
			
			JLabel label2 = new JLabel("Deal Information:");
			label2.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
			label2.setBounds(35, 17, 288, 22);
			panel1.add(label2);
			
			JLabel label3 = new JLabel("Deal ID:");
			label3.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			label3.setBounds(35, 65, 175, 16);
			panel1.add(label3);
			
			JLabel label4 = new JLabel("Customer ID:");
			label4.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			label4.setBounds(35, 90, 175, 16);
			panel1.add(label4);
			
			JLabel label5 = new JLabel("Deal Date:");
			label5.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			label5.setBounds(35, 118, 175, 16);
			panel1.add(label5);
			
			JLabel label6 = new JLabel("Vehicles Purchased:");
			label6.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			label6.setBounds(35, 146, 204, 16);
			panel1.add(label6);
			
			JLabel label7 = new JLabel("Shipping Cost:");
			label7.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			label7.setBounds(35, 174, 204, 16);
			panel1.add(label7);
			
			JLabel label8 = new JLabel("Total Deal Price:");
			label8.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			label8.setBounds(35, 202, 204, 16);
			panel1.add(label8);
			
			JLabel label1 = new JLabel("Find Deal By ID");
			label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
			label1.setBounds(50, 80, 273, 37);
			getContentPane().add(label1);
			panel1.setVisible(false);
			getContentPane().add(panel1);
			
			JLabel label12 = new JLabel("New label");
			label12.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			label12.setBounds(228, 66, 175, 16);
			panel1.add(label12);
			
			JLabel label13 = new JLabel("New label");
			label13.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			label13.setBounds(228, 91, 175, 16);
			panel1.add(label13);
			
			JLabel label14 = new JLabel("New label");
			label14.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
			label14.setBounds(228, 119, 235, 16);
			panel1.add(label14);
			
			JLabel label15 = new JLabel("New label");
			label15.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			label15.setBounds(228, 174, 175, 16);
			panel1.add(label15);
			
			JLabel label16 = new JLabel("New label");
			label16.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			label16.setBounds(228, 202, 175, 16);
			panel1.add(label16);
			
			JComboBox<String> vehiclesBox = new JComboBox<String>();
			vehiclesBox.setBounds(220, 138, 177, 37);
			panel1.add(vehiclesBox);
			
			JLabel label17 = new JLabel("AVG Pollution Level:");
			label17.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			label17.setBounds(35, 239, 204, 16);
			panel1.add(label17);
			
			JLabel label18 = new JLabel("New label");
			label18.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			label18.setBounds(228, 240, 175, 16);
			panel1.add(label18);
			

			
			comboBox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				if(comboBox.getSelectedIndex() != 0)
				{
					Deal d = (Deal) Main.libr.getAllDeals().get(comboBox.getSelectedItem());
					vehiclesBox.removeAllItems();
					vehiclesBox.addItem("Vehicles");
					for(VehicleTransportation v: d.getAllVehicleTransportation())
					{
						vehiclesBox.addItem(v.getLicensePlate());
					}
					
					label12.setText(d.getDealID());
					label13.setText(d.getCustomer().getID());
					label14.setText(d.getDealDate()+"");
					label15.setText(d.getShippingCost()+"");
					label16.setText(d.getTotalDealPrice()+"");
					label18.setText(String.valueOf(Main.libr.avgPollutionLevelOfDeal(d)));
					
					
					panel1.setVisible(true);

				}
				}
			});
			
			comboBox.setBounds(50, 130, 177, 37);
			getContentPane().add(comboBox);
			comboBox.addItem("Deals By ID:");
			for(Deal d: Main.libr.getAllDeals().values())
			{
					comboBox.addItem(d.getDealID());
			}

	}
}
