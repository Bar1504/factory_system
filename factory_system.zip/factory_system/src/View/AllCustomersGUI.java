package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Customer;
import model.Main;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AllCustomersGUI extends JInternalFrame {

	private JMenuBar menuBar;
	private JPanel panel1;
	private JList list;
	private ArrayList<String> customersToView = new ArrayList<>();
	private ArrayList<String> customersCmpToView = new ArrayList<>();

	public AllCustomersGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		

		JLabel label1 = new JLabel("View Customers");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 525, 37);
		getContentPane().add(label1);
		
		panel1 = new JPanel();
		panel1.setBounds(528, 138, 406, 399);
		panel1.setLayout(null);
		
		getContentPane().add(panel1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(6, 6, 255, 217);
		panel1.add(scrollPane);
		
		
		JLabel lblNewLabel = new JLabel("Choose how you would like to sort the customers:");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel.setBounds(50, 150, 399, 31);
		getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("By ID");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				customersToView.clear();
				for(Customer c: Main.libr.allCustomers())
				{
					customersToView.add(c.getID());
				}
				list = new JList( customersToView.toArray());
				scrollPane.setViewportView(list);
				
			}
		});
		btnNewButton.setBounds(50, 203, 222, 47);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("By Amount Of Deals And Vehicles");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				customersCmpToView.clear();
				for(Customer c: Main.libr.allCustomersCmp())
				{
					customersCmpToView.add(c.getID());
				}
				list = new JList( customersCmpToView.toArray());
				scrollPane.setViewportView(list);
			}
		});
		btnNewButton_1.setBounds(50, 276, 222, 47);
		getContentPane().add(btnNewButton_1);

	}
}
