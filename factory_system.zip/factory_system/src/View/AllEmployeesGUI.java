package View;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import model.Employee;
import model.Main;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.DefaultListModel;
import javax.swing.JButton;

public class AllEmployeesGUI extends JInternalFrame {

	private JMenuBar menuBar;
	private JTextField textField;
	private JPanel panel1;
	private JLabel label2;
	private JList list;
	private ArrayList<String> employeesToView = new ArrayList<>();

	public AllEmployeesGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		

		JLabel label1 = new JLabel("View Employees Sorted By Their ID");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 525, 37);
		getContentPane().add(label1);
		
		JLabel lblNewLabel = new JLabel("Choose The Amount Of Employees You Would Like To View");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel.setBounds(50, 137, 481, 16);
		getContentPane().add(lblNewLabel);
		
		panel1 = new JPanel();
		panel1.setBounds(528, 70, 406, 399);
		panel1.setLayout(null);
		label2 = new JLabel("Employees:");
		label2.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label2.setBounds(35, 17, 386, 22);
		panel1.add(label2);
		
		panel1.setVisible(false);
		getContentPane().add(panel1);
		
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, textField);
			}
		});
		textField.setBounds(50, 174, 130, 26);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("View");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Integer.parseInt(textField.getText())>0)
				{
					employeesToView.clear();
					for(Employee emp : Main.libr.allEmployees(Integer.parseInt(textField.getText())))
					{
						employeesToView.add(emp.getID());
					}
					list = new JList( employeesToView.toArray());
					JScrollPane scrollPane = new JScrollPane(list);
					panel1.setVisible(true);	
					scrollPane.setBounds(40, 70, 222, 100);
					panel1.add(scrollPane);
					scrollPane.setViewportView(list);
				}
				else
					list.setModel(new DefaultListModel());

			}
		});
		btnNewButton.setBounds(201, 174, 117, 29);
		getContentPane().add(btnNewButton);
	}
}
