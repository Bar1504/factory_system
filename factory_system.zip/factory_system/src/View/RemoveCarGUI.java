package View;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Car;
import model.HybridCar;
import model.Main;
import model.VehicleTransportation;
import utils.Color;

import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class RemoveCarGUI extends JInternalFrame {

	private JMenuBar menuBar;
	public RemoveCarGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		

		JLabel label1 = new JLabel("Remove Car By License Plate");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 344, 37);
		getContentPane().add(label1);
		JComboBox<String> comboBox = new JComboBox<String>();

		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(comboBox.getSelectedIndex() ==0)
					JOptionPane.showMessageDialog(null, "Select Car To Remove");
				else
				{
					int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to remove from the system?", "", JOptionPane.YES_NO_OPTION);
					if (reply == JOptionPane.YES_OPTION) 
					{
						Main.libr.removeCar((Car) Main.libr.getAllVehicleTransportation().get(comboBox.getSelectedItem()));
						comboBox.removeAllItems();
						comboBox.addItem("License Plates:");
						for(VehicleTransportation v: Main.libr.getAllVehicleTransportation().values())
						{
							if((v instanceof Car) && (!(v instanceof HybridCar)))
								comboBox.addItem(v.getLicensePlate());
						}
						try {
							Main.save();
							JOptionPane.showMessageDialog(null, "Car removed succefully");
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
				
				
			}
		});
		btnNewButton.setBounds(753, 480, 135, 46);
		getContentPane().add(btnNewButton);

		comboBox.addItem("License Plates:");
		for(VehicleTransportation v: Main.libr.getAllVehicleTransportation().values())
		{
			if((v instanceof Car) && (!(v instanceof HybridCar)))
				comboBox.addItem(v.getLicensePlate());
		}
		comboBox.setBounds(50, 130, 177, 37);
		getContentPane().add(comboBox);
		
	}

}
