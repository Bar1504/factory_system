package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.HybridCar;
import model.Main;
import model.VehicleTransportation;

public class FindHybridCarGUI extends JInternalFrame {

	private JMenuBar menuBar;
	public FindHybridCarGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		
		JPanel panel1 = new JPanel();
		panel1.setBounds(465, 70, 469, 368);
		panel1.setLayout(null);
		
		JLabel label2 = new JLabel("Hybrid Car Information:");
		label2.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label2.setBounds(35, 17, 253, 22);
		panel1.add(label2);
		
		JLabel label3 = new JLabel("New label");
		label3.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label3.setBounds(35, 65, 175, 16);
		panel1.add(label3);
		
		JLabel label4 = new JLabel("New label");
		label4.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label4.setBounds(35, 90, 175, 16);
		panel1.add(label4);
		
		JLabel label5 = new JLabel("New label");
		label5.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label5.setBounds(35, 118, 175, 16);
		panel1.add(label5);
		
		JLabel label6 = new JLabel("New label");
		label6.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label6.setBounds(35, 146, 204, 16);
		panel1.add(label6);
		
		JLabel label7 = new JLabel("New label");
		label7.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label7.setBounds(35, 174, 204, 16);
		panel1.add(label7);
		
		JLabel label8 = new JLabel("New label");
		label8.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label8.setBounds(35, 202, 204, 16);
		panel1.add(label8);
		
		JLabel label9 = new JLabel("New label");
		label9.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label9.setBounds(35, 230, 204, 16);
		panel1.add(label9);
		
		JLabel label10 = new JLabel("New label");
		label10.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label10.setBounds(35, 258, 209, 16);
		panel1.add(label10);
		
		JLabel label11 = new JLabel("New label");
		label11.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label11.setBounds(35, 286, 204, 16);
		panel1.add(label11);
		
		JLabel label1 = new JLabel("Find Hybrid Car By License Plate");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 356, 37);
		getContentPane().add(label1);
		panel1.setVisible(false);
		getContentPane().add(panel1);
		
		JLabel label12 = new JLabel("New label");
		label12.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label12.setBounds(228, 66, 175, 16);
		panel1.add(label12);
		
		JLabel label13 = new JLabel("New label");
		label13.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label13.setBounds(228, 91, 175, 16);
		panel1.add(label13);
		
		JLabel label14 = new JLabel("New label");
		label14.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label14.setBounds(228, 119, 175, 16);
		panel1.add(label14);
		
		JLabel label15 = new JLabel("New label");
		label15.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label15.setBounds(228, 147, 175, 16);
		panel1.add(label15);
		
		JLabel label16 = new JLabel("New label");
		label16.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label16.setBounds(228, 174, 175, 16);
		panel1.add(label16);
		
		JLabel label17 = new JLabel("New label");
		label17.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label17.setBounds(228, 202, 175, 16);
		panel1.add(label17);
		
		JLabel label18 = new JLabel("New label");
		label18.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label18.setBounds(228, 230, 175, 16);
		panel1.add(label18);
		
		JLabel label19 = new JLabel("New label");
		label19.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label19.setBounds(228, 258, 175, 16);
		panel1.add(label19);
		
		JLabel label20 = new JLabel("No");
		label20.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label20.setBounds(228, 286, 175, 16);
		panel1.add(label20);
		
		JLabel label21 = new JLabel("New label");
		label21.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label21.setBounds(35, 314, 204, 16);
		panel1.add(label21);
		
		JLabel label22 = new JLabel("New label");
		label22.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label22.setBounds(228, 315, 204, 16);
		panel1.add(label22);
		
		JLabel label23 = new JLabel("Profit:");
		label23.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label23.setBounds(35, 342, 204, 16);
		panel1.add(label23);
		
		JLabel label24 = new JLabel("New label");
		label24.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label24.setBounds(228, 342, 204, 16);
		panel1.add(label24);
		

		JComboBox<String> comboBox = new JComboBox<String>();
		
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			if(comboBox.getSelectedIndex() != 0)
			{
				HybridCar h= (HybridCar) Main.libr.getAllVehicleTransportation().get(comboBox.getSelectedItem());
				label3.setText("Liceense Plate: " );
				label4.setText("Price: " );
				label5.setText("Cost Of Manufacture: ");
				label6.setText("Color: " );
				label7.setText("Year Of Manufacture: ");
				label8.setText("Engine Capacity: ");
				label9.setText("Pollution Level: " );
				label10.setText("Number Of Seats: ");
				label11.setText("Is Convertible: ");
				label21.setText("Battery Capacity: ");
				
				label12.setText(h.getLicensePlate());
				label13.setText(h.getPrice() + "");
				label14.setText(h.getCostOfManufacturing() + "");
				label15.setText(h.getColor()+ "");
				label16.setText(h.getYearOfManufacture()+ "");
				label17.setText(h.getEngineCapacity()+ "");
				label18.setText(h.getPollutionLevel()+ "");
				label19.setText(h.getNumberOfSeats()+ "");
				if(h.isConvertible())
					label20.setText("Yes");
				label22.setText(h.getBatteryCapacity() + "");
				label24.setText(String.valueOf(Main.libr.profitPerVehiclesTransportation(h)));
				panel1.setVisible(true);

			}
			}
		});
		
		comboBox.setBounds(50, 130, 177, 37);
		getContentPane().add(comboBox);
		comboBox.addItem("License Plates:");
		for(VehicleTransportation v: Main.libr.getAllVehicleTransportation().values())
		{
			if(v instanceof HybridCar)
				comboBox.addItem(v.getLicensePlate());
		}

	}

}
