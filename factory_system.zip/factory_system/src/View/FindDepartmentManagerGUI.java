package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.DepartmentManager;
import model.Employee;
import model.Main;

public class FindDepartmentManagerGUI extends JInternalFrame {

	private JMenuBar menuBar;
	public FindDepartmentManagerGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		
		JPanel panel1 = new JPanel();
		panel1.setBounds(465, 70, 469, 399);
		panel1.setLayout(null);
		
		JLabel label2 = new JLabel("Department Manager Information:");
		label2.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label2.setBounds(35, 17, 386, 22);
		panel1.add(label2);
		
		JLabel label3 = new JLabel("Employee ID:");
		label3.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label3.setBounds(35, 65, 175, 16);
		panel1.add(label3);
		
		JLabel label4 = new JLabel("First Name:");
		label4.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label4.setBounds(35, 90, 175, 16);
		panel1.add(label4);
		
		JLabel label5 = new JLabel("Last Name:");
		label5.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label5.setBounds(35, 118, 175, 16);
		panel1.add(label5);
		
		JLabel label6 = new JLabel("Phone Number:");
		label6.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label6.setBounds(35, 146, 204, 16);
		panel1.add(label6);
		
		JLabel label7 = new JLabel("Gender:");
		label7.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label7.setBounds(35, 174, 204, 16);
		panel1.add(label7);
		
		JLabel label8 = new JLabel("Year Of Birth:");
		label8.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label8.setBounds(35, 202, 204, 16);
		panel1.add(label8);
		
		JLabel label9 = new JLabel("Date Of Start Work:");
		label9.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label9.setBounds(35, 230, 204, 16);
		panel1.add(label9);
		
		JLabel label10 = new JLabel("Salary:");
		label10.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label10.setBounds(35, 258, 209, 16);
		panel1.add(label10);
		
		JLabel label11 = new JLabel("Department:");
		label11.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label11.setBounds(35, 286, 204, 22);
		panel1.add(label11);
		
		JLabel label1 = new JLabel("Find Department Manager By ID");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 362, 37);
		getContentPane().add(label1);
		panel1.setVisible(false);
		getContentPane().add(panel1);
		
		JLabel label12 = new JLabel("New label");
		label12.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label12.setBounds(228, 66, 175, 16);
		panel1.add(label12);
		
		JLabel label13 = new JLabel("New label");
		label13.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label13.setBounds(228, 91, 175, 16);
		panel1.add(label13);
		
		JLabel label14 = new JLabel("New label");
		label14.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label14.setBounds(228, 119, 175, 16);
		panel1.add(label14);
		
		JLabel label15 = new JLabel("New label");
		label15.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label15.setBounds(228, 147, 175, 16);
		panel1.add(label15);
		
		JLabel label16 = new JLabel("New label");
		label16.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label16.setBounds(228, 174, 175, 16);
		panel1.add(label16);
		
		JLabel label17 = new JLabel("New label");
		label17.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label17.setBounds(228, 202, 175, 16);
		panel1.add(label17);
		
		JLabel label18 = new JLabel("New label");
		label18.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		label18.setBounds(228, 230, 235, 16);
		panel1.add(label18);
		
		JLabel label19 = new JLabel("New label");
		label19.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label19.setBounds(228, 260, 235, 16);
		panel1.add(label19);
		
		JLabel label20 = new JLabel("New label");
		label20.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label20.setBounds(228, 290, 235, 16);
		panel1.add(label20);
		
		JLabel label21 = new JLabel("Appointment Date:");
		label21.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label21.setBounds(35, 320, 204, 22);
		panel1.add(label21);
		
		JLabel label22 = new JLabel("Bonus:");
		label22.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label22.setBounds(35, 354, 204, 22);
		panel1.add(label22);
		
		JLabel label23 = new JLabel("New label");
		label23.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		label23.setBounds(228, 324, 235, 16);
		panel1.add(label23);
		
		JLabel label24 = new JLabel("New label");
		label24.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label24.setBounds(228, 354, 235, 16);
		panel1.add(label24);
		

		JComboBox<String> comboBox = new JComboBox<String>();
		
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			if(comboBox.getSelectedIndex() != 0)
			{
				DepartmentManager d = (DepartmentManager) Main.libr.getAllEmployees().get(comboBox.getSelectedItem());
			
				label12.setText(d.getID());
				label13.setText(d.getFirstName());
				label14.setText(d.getLastName());
				label15.setText(d.getPhoneNumber());
				label16.setText(d.getGender() +"");
				label17.setText(d.getYearOfBirth()+"");
				label18.setText(d.getDateOfStartWork()+"");
				label19.setText(d.getSalary()+"");
				label20.setText(d.getDep().getDepartmentID()+"");
				label23.setText(d.getAppointmentDate()+"");
				label24.setText(d.getBonus()+"");
				
				panel1.setVisible(true);

			}
			}
		});
		
		comboBox.setBounds(50, 130, 177, 37);
		getContentPane().add(comboBox);
		comboBox.addItem("Department Managers By ID:");
		for(Employee e: Main.libr.getAllEmployees().values())
		{
			if(e instanceof DepartmentManager)
				comboBox.addItem(e.getID());
		}

	}

}
