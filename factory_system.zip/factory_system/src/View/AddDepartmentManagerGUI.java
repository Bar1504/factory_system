package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import utils.Gender;
import com.toedter.calendar.JDateChooser;

import Exceptions.DateInvalidException;
import Exceptions.FieldMustBePositiveNumberException;
import Exceptions.PasswordLengthException;
import Exceptions.PersonAlreadyExistException;
import Exceptions.PhoneNumberInvalidException;
import Exceptions.YearOfBirthNotInRange;
import Exceptions.idInavlidException;
import model.Department;
import model.DepartmentManager;
import model.Main;
import javax.swing.JPasswordField;

public class AddDepartmentManagerGUI extends JInternalFrame {

	private JMenuBar menuBar;
	private JTextField IDField;
	private JTextField firstNameField;
	private JTextField phoneField;
	private JTextField lastNameField;
	private JTextField yearField;
	private Gender gender;
	private JTextField salaryField;
	private JTextField bonusField;
	private JPasswordField passField;
		public AddDepartmentManagerGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		JLabel lblNewLabel = new JLabel("Fill All The Fields To Add  A New Department Manager To The Factory");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel.setBounds(50, 40, 661, 27);
		getContentPane().add(lblNewLabel);
		JPanel panel = new JPanel();
		panel.setBounds(50, 90, 196, 474);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel IDLabel = new JLabel("ID:");
		IDLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		IDLabel.setBounds(0, 0, 144, 16);
		panel.add(IDLabel);
		
		JLabel firstNameLabel = new JLabel("First Name:");
		firstNameLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		firstNameLabel.setBounds(0, 80, 185, 25);
		panel.add(firstNameLabel);
		
		JLabel lastNameLabel = new JLabel("Last Name:");
		lastNameLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lastNameLabel.setBounds(0, 120, 144, 16);
		panel.add(lastNameLabel);
		
		JLabel phoneNumberLabel = new JLabel("Phone Number:");
		phoneNumberLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		phoneNumberLabel.setBounds(0, 160, 202, 16);
		panel.add(phoneNumberLabel);
		
		JLabel genderLabel = new JLabel("Gender:");
		genderLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		genderLabel.setBounds(0, 200, 144, 16);
		panel.add(genderLabel);
		
		JLabel yearLabel = new JLabel("Year Of Birth:");
		yearLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		yearLabel.setBounds(0, 240, 144, 16);
		panel.add(yearLabel);
		
		JLabel dateLabel = new JLabel("Date Of Start Work:");
		dateLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		dateLabel.setBounds(0, 280, 165, 16);
		panel.add(dateLabel);	
		
		JLabel salaryLabel = new JLabel("Salary:");
		salaryLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		salaryLabel.setBounds(0, 320, 165, 16);
		panel.add(salaryLabel);
		
		JLabel departmentLabel = new JLabel("Department:");
		departmentLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		departmentLabel.setBounds(0, 360, 165, 16);
		panel.add(departmentLabel);
		
		JLabel bonusLabel = new JLabel("Bonus:");
		bonusLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		bonusLabel.setBounds(0, 440, 165, 16);
		panel.add(bonusLabel);
		
		
		
		JLabel dateAppointmentLabel = new JLabel("Appointment Date:");
		dateAppointmentLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		dateAppointmentLabel.setBounds(0, 400, 165, 16);
		panel.add(dateAppointmentLabel);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblPassword.setBounds(0, 40, 144, 16);
		panel.add(lblPassword);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(246, 68, 223, 496);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		IDField = new JTextField();
		IDField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, IDField);
			}
		});
		IDField.setBounds(0, 10, 222, 35);
		panel_1.add(IDField);
		IDField.setColumns(10);
		
		firstNameField = new JTextField();
		firstNameField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c=e.getKeyChar();

			    if(!(Character.isAlphabetic(c) ||  (c==KeyEvent.VK_BACK_SPACE)||  c==KeyEvent.VK_DELETE ))
			    {
			        e.consume();
			        JOptionPane.showMessageDialog(null, "Enter alphabetic characters");
			    }				}
		});
		firstNameField.setColumns(10);
		firstNameField.setBounds(0, 95, 222, 35);
		panel_1.add(firstNameField);
		
		phoneField = new JTextField();
		phoneField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, phoneField);
			}
		});
		phoneField.setColumns(10);
		phoneField.setBounds(0, 175, 222, 35);
		panel_1.add(phoneField);
		
		lastNameField = new JTextField();
		lastNameField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c=e.getKeyChar();

			    if(!(Character.isAlphabetic(c) ||  (c==KeyEvent.VK_BACK_SPACE)||  c==KeyEvent.VK_DELETE ))
			    {
			        e.consume();
			        JOptionPane.showMessageDialog(null, "Enter alphabetic characters");
			    }	
			}
		});
		lastNameField.setColumns(10);
		lastNameField.setBounds(0, 135, 222, 35);
		panel_1.add(lastNameField);
		
		yearField = new JTextField();
		yearField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, yearField);

			}
		});
		yearField.setColumns(10);
		yearField.setBounds(0, 255, 222, 35);
		panel_1.add(yearField);
		ButtonGroup group = new ButtonGroup();
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Male");
		rdbtnNewRadioButton.setBounds(0, 215, 61, 23);
		panel_1.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gender = Gender.M;
			}
		});
		group.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Female");
		rdbtnNewRadioButton_1.setBounds(81, 215, 76, 23);
		panel_1.add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gender = Gender.F;
			}
		});
		group.add(rdbtnNewRadioButton_1);
		

		JDateChooser dateJoined = new JDateChooser();
		dateJoined.setDateFormatString("dd-M-yyyy hh:mm:ss");
		dateJoined.setBounds(0, 297, 222, 30);
		panel_1.add(dateJoined);
		
		
		
		salaryField = new JTextField();
		salaryField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinputOrDot(e, salaryField);

			}
		});
		salaryField.setColumns(10);
		salaryField.setBounds(0, 335, 222, 35);
		panel_1.add(salaryField);
		
		JComboBox <String>comboBox = new JComboBox();
		comboBox.setBounds(0, 374, 223, 35);
		panel_1.add(comboBox);
		comboBox.addItem("Departments");
		for(Department d: Main.libr.getAllDepartments().values())
		{
			comboBox.addItem(String.valueOf(d.getDepartmentID()));
		}
		
		JDateChooser appointmentDate = new JDateChooser();
		appointmentDate.setDateFormatString("dd-M-yyyy hh:mm:ss");
		appointmentDate.setBounds(0, 415, 222, 30);
		panel_1.add(appointmentDate);			
		
		bonusField = new JTextField();
		bonusField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinputOrDot(e, bonusField);

			}
		});
		bonusField.setColumns(10);
		bonusField.setBounds(0, 455, 222, 35);
		panel_1.add(bonusField);
		
		passField = new JPasswordField();
		passField.setBounds(0, 55, 222, 35);
		panel_1.add(passField);
		
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String password = new String(passField.getPassword());
				 if(IDField.getText().isEmpty() || firstNameField.getText().isEmpty() || lastNameField.getText().isEmpty() || phoneField.getText().isEmpty() || group.getSelection()==null
						 || group.getSelection()==null || yearField.getText().isEmpty() || salaryField.getText().isEmpty() || bonusField.getText().isEmpty() || password.isEmpty())
					JOptionPane.showMessageDialog(null, "Fill All Fields");
				 else if(dateJoined.getDate() == null)
						JOptionPane.showMessageDialog(null, "Date joined is invalid");
				 else if(appointmentDate.getDate() == null)
						JOptionPane.showMessageDialog(null, "Appointment date is invalid");
				else
				{
					int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to add department manager to the database?", "", JOptionPane.YES_NO_OPTION);
					if (reply == JOptionPane.YES_OPTION) 
					{
						double salary = 0, bonus = 0;
						try {
							salary = Double.parseDouble(salaryField.getText());
							bonus = Double.parseDouble(bonusField.getText());
						}
						catch (Exception e3)
						{}
						Department department = Main.libr.getAllDepartments().get(Integer.parseInt((String) comboBox.getSelectedItem()));
						DepartmentManager depManager = new DepartmentManager(IDField.getText(), firstNameField.getText(),lastNameField.getText(), phoneField.getText(), 
								gender, dateJoined.getDate(), Double.parseDouble(salaryField.getText()), department,Integer.parseInt(yearField.getText()),
								appointmentDate.getDate(), Double.parseDouble(bonusField.getText()),password);
						try {
							Main.libr.addDepartmentManager(depManager);
							IDField.setText("");
							firstNameField.setText("");
							lastNameField.setText("");
							lastNameField.setText("");
							phoneField.setText("");
							yearField.setText("");
							group.clearSelection();
							salaryField.setText("");
							comboBox.setSelectedIndex(0);
							dateJoined.setDate(null);
							appointmentDate.setDate(null);
							bonusField.setText("");
							passField.setText("");
							try {
								Main.save();
								JOptionPane.showMessageDialog(null, "Department manager added succefully");
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						} catch (PersonAlreadyExistException | YearOfBirthNotInRange | PhoneNumberInvalidException
								| idInavlidException | DateInvalidException | FieldMustBePositiveNumberException | PasswordLengthException
								 e1) {
							JOptionPane.showMessageDialog(null, e1.getMessage());
						}
							
						
					}
				}
			}
		});
		btnNewButton.setBounds(750, 520, 117, 44);
		getContentPane().add(btnNewButton);
	}
}
