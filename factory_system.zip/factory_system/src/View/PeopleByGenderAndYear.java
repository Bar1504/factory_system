package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import model.Main;
import model.Person;
import utils.Area;
import utils.Gender;

import javax.swing.JRadioButton;

public class PeopleByGenderAndYear extends JInternalFrame {

	private JMenuBar menuBar;
	private JList<String> list;
	private JPanel panel1;
	private JLabel label2;
	JComboBox<String> comboBox = new JComboBox<String>();
	ArrayList<String> peopleByGenderAndYearOfBirth = new ArrayList<>();
	Gender gender;

	public PeopleByGenderAndYear(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		


		JLabel label1 = new JLabel("Choose a Gender And Year Of Birth");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 409, 37);
		getContentPane().add(label1);
		
		
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Male");
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(Integer year: Main.libr.personsByGenderAndYearOfBirth().get(Gender.M).keySet())
				{
					comboBox.addItem(String.valueOf(year));
				}
				comboBox.setEnabled(true);
				gender = Gender.M;
				
			}
		});
		
		rdbtnNewRadioButton.setBounds(60, 135, 61, 23);
		getContentPane().add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnFemale = new JRadioButton("Female");
		rdbtnFemale.setBounds(151, 135, 76, 23);
		getContentPane().add(rdbtnFemale);
		ButtonGroup group = new ButtonGroup();
		group.add(rdbtnNewRadioButton);
		group.add(rdbtnFemale);
		
		//comboBox.setEnabled(false);
		comboBox.addItem("Year Of Birth:");
		comboBox.setBounds(50, 170, 177, 37);
		getContentPane().add(comboBox);
		comboBox.setEnabled(false);
		
		
		
		
		
		
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox.getSelectedIndex() != 0)
				{
					peopleByGenderAndYearOfBirth.removeAll(peopleByGenderAndYearOfBirth);
					
					for(Person p : Main.libr.personsByGenderAndYearOfBirth().get(gender).get(Integer.parseInt((String) comboBox.getSelectedItem())))
					{
						peopleByGenderAndYearOfBirth.add(p.getID());
					}
					//label2.setText("Customers From " + comboBox.getSelectedItem());
					list = new JList( peopleByGenderAndYearOfBirth.toArray());
					JScrollPane scrollPane = new JScrollPane(list);
					panel1.setVisible(true);	
					scrollPane.setBounds(40, 70, 222, 100);
					panel1.add(scrollPane);
					scrollPane.setViewportView(list);
				}
			}
		});
		
		
	
		panel1 = new JPanel();
		panel1.setBounds(465, 70, 469, 399);
		panel1.setLayout(null);
		label2 = new JLabel("People by The Chosen Gender and Year of Birth");
		label2.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 17));
		label2.setBounds(35, 17, 428, 22);
		panel1.add(label2);
		
		panel1.setVisible(false);
		getContentPane().add(panel1);
		
		
		
	}
}
