package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import model.DepartmentManager;
import model.Main;

public class AllBestDepManagersGUI extends JInternalFrame {

	private JMenuBar menuBar;
	private JPanel panel1;
	private JList list;
	private ArrayList<String> depManagersToView = new ArrayList<>();
	public AllBestDepManagersGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		

		JLabel label1 = new JLabel("Department Manager By Salary And Appointment Date");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 593, 37);
		getContentPane().add(label1);
		
		panel1 = new JPanel();
		panel1.setBounds(50, 140, 406, 399);
		panel1.setLayout(null);
		
		getContentPane().add(panel1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(6, 6, 255, 217);
		panel1.add(scrollPane);
		for(DepartmentManager dm: Main.libr.AllBestsDepManger())
		{
			depManagersToView.add(dm.getID());
		}
		list = new JList( depManagersToView.toArray());
		scrollPane.setViewportView(list);
	}

}
