package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.TreeSet;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

import utils.Gender;
import javax.swing.JList;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import java.awt.ScrollPane;
import com.toedter.calendar.JDateChooser;

import Exceptions.DateInvalidException;
import Exceptions.FieldMustBePositiveNumberException;
import Exceptions.VehicleNotForSaleException;
import model.Customer;
import model.Deal;
import model.Main;
import model.VehicleTransportation;
public class AddDealGUI extends JInternalFrame {

	private JMenuBar menuBar;
	private JTextField shippingField;

	private JComboBox dealBox;

	public AddDealGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		JLabel lblNewLabel = new JLabel("Fill All The Fields To Add  A New Deal To The Factory");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel.setBounds(50, 80, 661, 27);
		getContentPane().add(lblNewLabel);
		JPanel panel = new JPanel();
		panel.setBounds(50, 130, 196, 393);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel customerLabel = new JLabel("Choose Customer:");
		customerLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		customerLabel.setBounds(0, 0, 144, 16);
		panel.add(customerLabel);
		
		JLabel vehiclesLabel = new JLabel("Choose Vehicles:");
		vehiclesLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		vehiclesLabel.setBounds(0, 80, 185, 25);
		panel.add(vehiclesLabel);
		
		JLabel shippingLabel = new JLabel("Shipping Cost:");
		shippingLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		shippingLabel.setBounds(0, 200, 144, 25);
		panel.add(shippingLabel);
		
		JLabel dateLabel = new JLabel("Deal Date:");
		dateLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		dateLabel.setBounds(0, 40, 185, 25);
		panel.add(dateLabel);
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(246, 108, 223, 415);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		shippingField = new JTextField();
		shippingField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinputOrDot(e, shippingField);
			}
		});
		shippingField.setBounds(0, 210, 222, 35);
		panel_1.add(shippingField);
		shippingField.setColumns(10);
		ArrayList<String> vehicles = new ArrayList<>(Main.libr.getVehiclesForSale().keySet());
		JList<String> list = new JList(vehicles.toArray());
		list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		list.setBounds(0, 62, 207, 24);
		
		JScrollPane scrollPane = new JScrollPane(list);
		scrollPane.setBounds(0, 100, 222, 88);
		panel_1.add(scrollPane);
		
		
		dealBox = new JComboBox<String>();
		dealBox.setBounds(0, 16, 222, 35);
		panel_1.add(dealBox);
		dealBox.addItem("Customers");
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(0, 60, 222, 26);
		panel_1.add(dateChooser);
		
		for(Customer c: Main.libr.getAllCustomers().values())
		{
			dealBox.addItem(c.getID());
		}
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(dealBox.getSelectedIndex() ==0)
					JOptionPane.showMessageDialog(null, "Select Customer");
				//else if(list.getSelectedIndex() ==0)
				//	JOptionPane.showMessageDialog(null, "Select Vehicle");
				else if(shippingField.getText().isEmpty())
					JOptionPane.showMessageDialog(null, "Enter Shipping Cost");
				else if(dateChooser.getDate() == null)
				JOptionPane.showMessageDialog(null, "Date is invalid");
				else
				{
					int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to add deal to the database?", "", JOptionPane.YES_NO_OPTION);
					if (reply == JOptionPane.YES_OPTION) 
					{
						HashSet<VehicleTransportation> vehiclesInDeal = new HashSet<>();
						for(String s: list.getSelectedValuesList())
						{
							vehiclesInDeal.add(Main.libr.getAllVehicleTransportation().get(s));
						}
						double shippingCost = 0;
						try {
							shippingCost = Double.parseDouble(shippingField.getText());
						}
						catch(Exception e3)
						{
						}
						
						Deal deal = new Deal(Main.libr.getAllCustomers().get(dealBox.getSelectedItem()), dateChooser.getDate(), vehiclesInDeal, Double.parseDouble(shippingField.getText()));
						try {
							Main.libr.addDeal(deal);
							dealBox.setSelectedIndex(0);
							dateChooser.setDate(null);
							list.clearSelection();
							shippingField.setText("");
					try {
								Main.libr.setDealCounter(Main.libr.getDealCounter()+1);
								Main.save();
								JOptionPane.showMessageDialog(null, "Deal added succefully");

							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						} catch (DateInvalidException | FieldMustBePositiveNumberException | VehicleNotForSaleException
								 e2) {
							Deal.setCounter(Deal.getCounter()-1);
							JOptionPane.showMessageDialog(null, e2.getMessage());
						}
						
					}
				}
			}
		});
		btnNewButton.setBounds(750, 520, 117, 44);
		getContentPane().add(btnNewButton);
		
		
	}
}
