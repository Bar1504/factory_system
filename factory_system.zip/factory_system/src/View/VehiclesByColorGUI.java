package View;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.border.EmptyBorder;

import model.Main;
import utils.Color;

import javax.swing.JPanel;

public class VehiclesByColorGUI extends JInternalFrame {


	private JMenuBar menuBar;
	public VehiclesByColorGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		

		JLabel label1 = new JLabel("Vehicles By Color");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 409, 37);
		getContentPane().add(label1);
		
		JPanel panel = new JPanel();
		panel.setBounds(50, 161, 124, 319);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel blackLabel = new JLabel("Black:");
		blackLabel.setBounds(6, 6, 77, 16);
		panel.add(blackLabel);
		
		JLabel blueLabel = new JLabel("Blue:");
		blueLabel.setBounds(6, 46, 77, 16);
		panel.add(blueLabel);
		
		JLabel goldLabel = new JLabel("Gold:");
		goldLabel.setBounds(6, 86, 77, 16);
		panel.add(goldLabel);
		
		JLabel grayLabel = new JLabel("Gray:");
		grayLabel.setBounds(6, 126, 77, 16);
		panel.add(grayLabel);
		
		JLabel greenLabel = new JLabel("Green:");
		greenLabel.setBounds(6, 166, 77, 16);
		panel.add(greenLabel);
		
		JLabel redLabel = new JLabel("Red:");
		redLabel.setBounds(6, 206, 77, 16);
		panel.add(redLabel);
		
		JLabel silverLabel = new JLabel("Silver:");
		silverLabel.setBounds(6, 246, 77, 16);
		panel.add(silverLabel);
		
		JLabel whiteLabel = new JLabel("White:");
		whiteLabel.setBounds(6, 286, 77, 16);
		panel.add(whiteLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(200, 161, 124, 319);
		getContentPane().add(panel_1);
		
		JLabel blackCountLabel = new JLabel(String.valueOf(Main.libr.countOfVehiclesTransportationByColor().get(Color.Black)));
		blackCountLabel.setBounds(6, 6, 77, 16);
		panel_1.add(blackCountLabel);
		
		JLabel blueCountLabel = new JLabel(String.valueOf(Main.libr.countOfVehiclesTransportationByColor().get(Color.Blue)));
		blueCountLabel.setBounds(6, 46, 77, 16);
		panel_1.add(blueCountLabel);
		
		JLabel goldCountLabel = new JLabel(String.valueOf(Main.libr.countOfVehiclesTransportationByColor().get(Color.Gold)));
		System.out.println(String.valueOf(Main.libr.countOfVehiclesTransportationByColor().get(Color.Gold)));
		goldCountLabel.setBounds(6, 86, 77, 16);
		panel_1.add(goldCountLabel);
		
		JLabel grayCountLabel = new JLabel(String.valueOf(Main.libr.countOfVehiclesTransportationByColor().get(Color.Gray)));
		grayCountLabel.setBounds(6, 126, 77, 16);
		panel_1.add(grayCountLabel);
		
		JLabel greenCountLabel = new JLabel(String.valueOf(Main.libr.countOfVehiclesTransportationByColor().get(Color.Green)));
		greenCountLabel.setBounds(6, 166, 77, 16);
		panel_1.add(greenCountLabel);
		
		JLabel redCountLabel = new JLabel(String.valueOf(Main.libr.countOfVehiclesTransportationByColor().get(Color.Red)));
		redCountLabel.setBounds(6, 206, 77, 16);
		panel_1.add(redCountLabel);
		
		JLabel silverCountLabel = new JLabel(String.valueOf(Main.libr.countOfVehiclesTransportationByColor().get(Color.Silver)));
		silverCountLabel.setBounds(6, 246, 77, 16);
		panel_1.add(silverCountLabel);
		
		JLabel whiteCountLabel = new JLabel(String.valueOf(Main.libr.countOfVehiclesTransportationByColor().get(Color.White)));
		whiteCountLabel.setBounds(6, 286, 77, 16);
		panel_1.add(whiteCountLabel);
	
	}
}
