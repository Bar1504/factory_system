package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Customer;
import model.Main;
import utils.Area;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class CustomersByAreaGUI extends JInternalFrame {

	private JMenuBar menuBar;
	private JList<String> list;
	private JPanel panel1;
	private JLabel label2;
	private ArrayList<String> customersByID = new ArrayList<>();
	public CustomersByAreaGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		

		JLabel label1 = new JLabel("Choose an Area");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 409, 37);
		getContentPane().add(label1);
		JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox.getSelectedIndex() != 0)
				{
					customersByID.removeAll(customersByID);		
					for(Customer c : Main.libr.customersByArea().get(Area.valueOf((String) comboBox.getSelectedItem())))
					{
							customersByID.add(c.getID());
					}
					label2.setText("Customers From " + comboBox.getSelectedItem());
					list = new JList( customersByID.toArray());
					JScrollPane scrollPane = new JScrollPane(list);
					panel1.setVisible(true);	
					scrollPane.setBounds(40, 70, 222, 100);
					panel1.add(scrollPane);
					scrollPane.setViewportView(list);
				}
			}
		});	
		
		comboBox.addItem("Areas:");
		for(Area a: Area.values())
		{
			comboBox.addItem(a.name());
		}
		comboBox.setBounds(50, 130, 177, 37);
		getContentPane().add(comboBox);
		
		panel1 = new JPanel();
		panel1.setBounds(465, 70, 469, 399);
		panel1.setLayout(null);
		label2 = new JLabel("Customer From");
		label2.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label2.setBounds(35, 17, 386, 22);
		panel1.add(label2);
		
		panel1.setVisible(false);
		getContentPane().add(panel1);
		
		HashMap<Area, ArrayList<Customer>> customersByArea = Main.libr.customersByArea();
		
	}
}
