package View;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import model.Employee;
import model.Main;

import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Panel;
import java.awt.Toolkit;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.SystemColor;

public class LoginGUI extends JFrame {

	private JPanel contentPane;
	private JTextField userTextField;
	private JPasswordField passwordField;

	public LoginGUI()  {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 200, 467, 321);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.window);
		setContentPane(contentPane);
		this.setResizable(true);
		contentPane.setLayout(null);		
		
		JLabel label1 = new JLabel("Enter username and password to login ");
		label1.setBounds(41, 91, 307, 20);
		contentPane.add(label1);
		label1.setFont(new Font("Lucida Grande", Font.ITALIC, 16));
		
		JLabel userLabel = new JLabel("Username:");
		userLabel.setBounds(41, 134, 83, 20);
		contentPane.add(userLabel);
		userLabel.setFont(new Font("Lucida Grande", Font.ITALIC, 16));
		
		userTextField = new JTextField();
		userTextField.setBounds(129, 127, 187, 35);
		contentPane.add(userTextField);
		userTextField.setColumns(10);
		
		JLabel passLabel = new JLabel("Password:");
		passLabel.setBounds(41, 176, 78, 20);
		contentPane.add(passLabel);
		passLabel.setFont(new Font("Lucida Grande", Font.ITALIC, 16));
		
		passwordField = new JPasswordField();
		passwordField.setBounds(129, 165, 187, 35);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("LOG IN");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String password = new String(passwordField.getPassword());
				Employee employee = Main.libr.getAllEmployees().get(userTextField.getText());
				if(userTextField.getText().equals("admin") && password.equals("admin"))
				{
					dispose();
					new AdminGUI();
					
				}				
				else if(employee!= null)
				{
					if(employee.getPassword().equals(password))
					{
						dispose();
						new EmployeeGUI();
					}
					else
						JOptionPane.showMessageDialog(null, "Wrong password");
				}
				
				else if((userTextField.getText().isEmpty() ) || (password.isEmpty()))
					JOptionPane.showMessageDialog(null, "Fill all Fields");
				else 
				{
					JOptionPane.showMessageDialog(null, "Wrong username or password, try again");
				}
			}
		});
		btnNewButton.setBounds(329, 232, 83, 35);
		contentPane.add(btnNewButton);
	}
}
