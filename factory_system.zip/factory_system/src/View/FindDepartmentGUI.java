package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Department;
import model.Employee;
import model.Main;

import javax.swing.JButton;

public class FindDepartmentGUI extends JInternalFrame {

	private JMenuBar menuBar;
	JComboBox<String> comboBox = new JComboBox<String>();

	public FindDepartmentGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		
		JPanel panel1 = new JPanel();
		panel1.setBounds(465, 70, 469, 399);
		panel1.setLayout(null);
		
		JLabel label2 = new JLabel("Department Information:");
		label2.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label2.setBounds(35, 17, 288, 22);
		panel1.add(label2);
		
		JLabel label3 = new JLabel("Department ID:");
		label3.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label3.setBounds(35, 65, 175, 16);
		panel1.add(label3);
		
		JLabel label4 = new JLabel("Specialization:");
		label4.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label4.setBounds(35, 90, 175, 16);
		panel1.add(label4);
		
		JLabel label5 = new JLabel("Manager ID:");
		label5.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label5.setBounds(35, 118, 204, 22);
		panel1.add(label5);
		
		JLabel label6 = new JLabel("Employees:");
		label6.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label6.setBounds(35, 146, 204, 16);
		panel1.add(label6);
		
		JLabel label1 = new JLabel("Find Department By ID");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 273, 37);
		getContentPane().add(label1);
		panel1.setVisible(false);
		getContentPane().add(panel1);
		
		JLabel label12 = new JLabel("New label");
		label12.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label12.setBounds(228, 66, 175, 16);
		panel1.add(label12);
		
		JLabel label13 = new JLabel("New label");
		label13.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label13.setBounds(228, 91, 175, 16);
		panel1.add(label13);
		
		JLabel label14 = new JLabel("New label");
		label14.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		label14.setBounds(228, 119, 235, 16);
		panel1.add(label14);
		
		JComboBox<String> employeesBox = new JComboBox<String>();
		employeesBox.setBounds(220, 138, 177, 37);
		panel1.add(employeesBox);
		

		
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			if(comboBox.getSelectedIndex() != 0)
			{
				Department d = (Department) Main.libr.getAllDepartments().get(Integer.parseInt((String) comboBox.getSelectedItem()));
				employeesBox.removeAllItems();
				employeesBox.addItem("Employees");
				for(Employee emp: d.getAllEmployees())
				{
					employeesBox.addItem(emp.getID());
				}
				
				label12.setText(d.getDepartmentID()+"");
				label13.setText(d.getSpecialization()+"");
				if(d.getDepManager()!= null)
					label14.setText(d.getDepManager().getID());
				else
					label14.setText("Does Not Exist");
				
				
				panel1.setVisible(true);

			}
			}
		});
		
		comboBox.setBounds(50, 130, 177, 37);
		getContentPane().add(comboBox);
		comboBox.addItem("Departments By ID");
		for(Department d: Main.libr.getAllDepartments().values())
		{
				comboBox.addItem(d.getDepartmentID()+"");
		}

	}

}
