package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;

import Exceptions.DateInvalidException;
import Exceptions.DiscountPercentageInvalid;
import Exceptions.PersonAlreadyExistException;
import Exceptions.PhoneNumberInvalidException;
import Exceptions.YearOfBirthNotInRange;
import Exceptions.idInavlidException;
import model.Main;
import model.VIPCustomer;
import utils.Area;
import utils.Color;
import utils.Gender;
import javax.swing.JScrollPane;
import javax.swing.JList;

public class AddVIPCustomerGUI extends JInternalFrame {

	private JMenuBar menuBar;
	private JTextField IDField;
	private JTextField firstNameField;
	private JTextField phoneField;
	private JTextField lastNameField;
	private JTextField yearField;
	private JComboBox comboBox;
	private Gender gender;
	private JTextField discountField;
	public AddVIPCustomerGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		JLabel lblNewLabel = new JLabel("Fill All The Fields To Add  A New VIP Customer To The Factory");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel.setBounds(50, 80, 635, 27);
		getContentPane().add(lblNewLabel);
		JPanel panel = new JPanel();
		panel.setBounds(50, 130, 196, 434);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel IDLabel = new JLabel("ID:");
		IDLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		IDLabel.setBounds(0, 0, 144, 16);
		panel.add(IDLabel);
		
		JLabel firstNameLabel = new JLabel("First Name:");
		firstNameLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		firstNameLabel.setBounds(0, 40, 185, 25);
		panel.add(firstNameLabel);
		
		JLabel lastNameLabel = new JLabel("Last Name:");
		lastNameLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lastNameLabel.setBounds(0, 80, 144, 16);
		panel.add(lastNameLabel);
		
		JLabel phoneNumberLabel = new JLabel("Phone Number:");
		phoneNumberLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		phoneNumberLabel.setBounds(0, 120, 202, 16);
		panel.add(phoneNumberLabel);
		
		JLabel genderLabel = new JLabel("Gender:");
		genderLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		genderLabel.setBounds(0, 160, 144, 16);
		panel.add(genderLabel);
		
		JLabel yearLabel = new JLabel("Year Of Birth:");
		yearLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		yearLabel.setBounds(0, 200, 144, 16);
		panel.add(yearLabel);
		
		JLabel areaLabel = new JLabel("Area:");
		areaLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		areaLabel.setBounds(0, 240, 144, 16);
		panel.add(areaLabel);
		
		JLabel dateJoinedLabel = new JLabel("Date Of Joining:");
		dateJoinedLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		dateJoinedLabel.setBounds(0, 277, 144, 25);
		panel.add(dateJoinedLabel);
		
		JLabel discountLabel = new JLabel("Discount Percentage:");
		discountLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		discountLabel.setBounds(0, 317, 165, 16);
		panel.add(discountLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(246, 108, 223, 456);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		IDField = new JTextField();
		IDField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, IDField);
			}
		});
		IDField.setBounds(0, 10, 222, 35);
		panel_1.add(IDField);
		IDField.setColumns(10);
		
		firstNameField = new JTextField();
		firstNameField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c=e.getKeyChar();

			    if(!(Character.isAlphabetic(c) ||  (c==KeyEvent.VK_BACK_SPACE)||  c==KeyEvent.VK_DELETE ))
			    {
			        e.consume();
			        JOptionPane.showMessageDialog(null, "Enter alphabetic characters");
			    }				}
		});
		firstNameField.setColumns(10);
		firstNameField.setBounds(0, 55, 222, 35);
		panel_1.add(firstNameField);
		
		phoneField = new JTextField();
		phoneField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, phoneField);
			}
		});
		phoneField.setColumns(10);
		phoneField.setBounds(0, 135, 222, 35);
		panel_1.add(phoneField);
		
		lastNameField = new JTextField();
		lastNameField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c=e.getKeyChar();

			    if(!(Character.isAlphabetic(c) ||  (c==KeyEvent.VK_BACK_SPACE)||  c==KeyEvent.VK_DELETE ))
			    {
			        e.consume();
			        JOptionPane.showMessageDialog(null, "Enter alphabetic characters");
			    }	
			}
		});
		lastNameField.setColumns(10);
		lastNameField.setBounds(0, 95, 222, 35);
		panel_1.add(lastNameField);
		
		yearField = new JTextField();
		yearField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, yearField);

			}
		});
		yearField.setColumns(10);
		yearField.setBounds(0, 215, 222, 35);
		panel_1.add(yearField);
		
		comboBox = new JComboBox<String>();
		comboBox.setBounds(0, 255, 222, 35);
		panel_1.add(comboBox);
		comboBox.addItem("Areas");
		for(Area area: Area.values())
		{
			comboBox.addItem(area.name());
		}
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setDateFormatString("dd-M-yyyy hh:mm:ss");
		dateChooser.setBounds(0, 297, 217, 26);
		panel_1.add(dateChooser);
		
		ButtonGroup group = new ButtonGroup();
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Male");
		rdbtnNewRadioButton.setBounds(0, 175, 141, 23);
		panel_1.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gender = Gender.M;
			}
		});
		group.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Female");
		rdbtnNewRadioButton_1.setBounds(81, 175, 141, 23);
		panel_1.add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gender = Gender.F;
			}
		});
		group.add(rdbtnNewRadioButton_1);
		
		discountField = new JTextField();
		discountField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinputOrDot(e, discountField);

			}
		});
		discountField.setColumns(10);
		discountField.setBounds(0, 330, 222, 35);
		panel_1.add(discountField);
		
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox.getSelectedIndex() ==0)
					JOptionPane.showMessageDialog(null, "Select Area");
				else if(IDField.getText().isEmpty() || firstNameField.getText().isEmpty() || lastNameField.getText().isEmpty() || phoneField.getText().isEmpty() || group.getSelection()==null
						 || group.getSelection()==null || yearField.getText().isEmpty() || discountField.getText().isEmpty())
					JOptionPane.showMessageDialog(null, "Fill All Fields");
				else if(dateChooser.getDate() == null)
					JOptionPane.showMessageDialog(null, "Date is invalid");
				else
				{
					int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to add vip customer to the database?", "", JOptionPane.YES_NO_OPTION);
					if (reply == JOptionPane.YES_OPTION) 
					{
						Area area = Area.valueOf((String) comboBox.getSelectedItem());
						VIPCustomer vipCustomer = new VIPCustomer(IDField.getText(), firstNameField.getText(),lastNameField.getText(), phoneField.getText(), 
								gender, Integer.parseInt(yearField.getText()),area, dateChooser.getDate(), Double.parseDouble(discountField.getText()));
						
						try {
							Main.libr.addVIPCustomer(vipCustomer);
							IDField.setText("");
							firstNameField.setText("");
							lastNameField.setText("");
							lastNameField.setText("");
							phoneField.setText("");
							yearField.setText("");
							comboBox.setSelectedIndex(0);
							group.clearSelection();
							dateChooser.setDate(null);
							discountField.setText("");
							try {
							Main.save();
							JOptionPane.showMessageDialog(null, "VIP customer added succefully");
							}
						 catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}	
						} catch (PersonAlreadyExistException | YearOfBirthNotInRange | PhoneNumberInvalidException | idInavlidException | DateInvalidException | DiscountPercentageInvalid e1) {
							JOptionPane.showMessageDialog(null, e1.getMessage());
						}
					}
				}
			}
		});
		btnNewButton.setBounds(750, 515, 117, 44);
		getContentPane().add(btnNewButton);

	}
}
