package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.HashSet;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Exceptions.DepartmentAlreadyExistsException;
import model.Department;
import model.Main;
import utils.Color;
import utils.Specialization;

public class AddDepartmentGUI extends JInternalFrame {
	private JMenuBar menuBar;
	private JTextField idField;
	private JTextField firstNameField;
	private JComboBox comboBox;
	public AddDepartmentGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		JLabel lblNewLabel = new JLabel("Fill All The Fields To Add  A New Department To The Factory");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel.setBounds(50, 80, 661, 27);
		getContentPane().add(lblNewLabel);
		JPanel panel = new JPanel();
		panel.setBounds(50, 130, 196, 393);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel idLabel = new JLabel("Department ID:");
		idLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		idLabel.setBounds(0, 0, 144, 16);
		panel.add(idLabel);
		
		JLabel specialLabel = new JLabel("Specialization:");
		specialLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		specialLabel.setBounds(0, 40, 185, 25);
		panel.add(specialLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(246, 108, 223, 415);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		idField = new JTextField();
		idField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, idField);
			}
		});
		idField.setBounds(0, 15, 222, 35);
		panel_1.add(idField);
		idField.setColumns(10);
		comboBox = new JComboBox<String>();
		comboBox.setBounds(0, 60, 222, 35);
		panel_1.add(comboBox);
		comboBox.addItem("Specializations");
		for(Specialization s: Specialization.values())
		{
			comboBox.addItem(s.name());
		}

		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox.getSelectedIndex() ==0)
					JOptionPane.showMessageDialog(null, "Select Specialization");
				else if(idField.getText().isEmpty())
					JOptionPane.showMessageDialog(null, "Enter ID");
				else
				{
					int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to add department to the database?", "", JOptionPane.YES_NO_OPTION);
					if (reply == JOptionPane.YES_OPTION) 
					{
						Specialization specialization = Specialization.valueOf((String) comboBox.getSelectedItem());
						Department department = new Department(Integer.parseInt(idField.getText()), specialization);
						try {
							Main.libr.addDepartment(department);
							comboBox.setSelectedIndex(0);
							idField.setText("");
							try {
								Main.save();
								JOptionPane.showMessageDialog(null, "Department added succefully");
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						} catch (DepartmentAlreadyExistsException e2) {
							// TODO Auto-generated catch block
							JOptionPane.showMessageDialog(null, e2.getMessage());
						}
						
					}
				}
			}
		});
		btnNewButton.setBounds(750, 520, 117, 44);
		getContentPane().add(btnNewButton);
	}

}
