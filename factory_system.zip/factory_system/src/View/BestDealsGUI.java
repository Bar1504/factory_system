package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import model.ArithmeticMean;
import model.Deal;
import model.GeometricMean;
import model.HarmonicMean;
import model.Main;

import javax.swing.JComboBox;

public class BestDealsGUI extends JInternalFrame {

	private JMenuBar menuBar;
	private JTextField textField;
	private JPanel panel1;
	private JLabel label2;
	private JList list;
	private ArrayList<String> bestDealsToView = new ArrayList<>();
	JComboBox <String>comboBox = new JComboBox();


	public BestDealsGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		

		JLabel label1 = new JLabel("View Best Deals");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 525, 37);
		getContentPane().add(label1);
		
		JLabel lblNewLabel = new JLabel("Choose The Amount Of Deals:");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel.setBounds(50, 137, 481, 16);
		getContentPane().add(lblNewLabel);
		
		panel1 = new JPanel();
		panel1.setBounds(528, 70, 406, 399);
		panel1.setLayout(null);
		label2 = new JLabel("Deals");
		label2.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label2.setBounds(35, 17, 386, 22);
		panel1.add(label2);
		
		panel1.setVisible(false);
		getContentPane().add(panel1);
		
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, textField);
			}
		});
		textField.setBounds(298, 133, 130, 26);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		comboBox.setBounds(298, 193, 137, 27);
		getContentPane().add(comboBox);
		comboBox.addItem("Score Calculators");
		comboBox.addItem("ArithmeticMean");
		comboBox.addItem("GeometricMean");
		comboBox.addItem("HarmonicMean");
		
		
		JButton btnNewButton = new JButton("View Deals");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Integer.parseInt(textField.getText())>0)
				{
					bestDealsToView.clear();
					if(comboBox.getSelectedItem().equals("ArithmeticMean"))
					{
						for(Deal d : Main.libr.getBestsDeal((Integer.parseInt(textField.getText())), new ArithmeticMean()))
						{
							bestDealsToView.add(d.getDealID());
						}
					}
					else if(comboBox.getSelectedItem().equals("GeometricMean"))
					{
						for(Deal d : Main.libr.getBestsDeal((Integer.parseInt(textField.getText())), new GeometricMean()))
						{
							bestDealsToView.add(d.getDealID());
						}
					}
					else
					{
						for(Deal d : Main.libr.getBestsDeal((Integer.parseInt(textField.getText())), new HarmonicMean()))
						{
							bestDealsToView.add(d.getDealID());
						}
					}
					list = new JList( bestDealsToView.toArray());
					JScrollPane scrollPane = new JScrollPane(list);
					panel1.setVisible(true);	
					scrollPane.setBounds(40, 70, 222, 100);
					panel1.add(scrollPane);
					scrollPane.setViewportView(list);
				}
				else
					list.setModel(new DefaultListModel());

			}
		});
		btnNewButton.setBounds(50, 262, 130, 42);
		getContentPane().add(btnNewButton);
		
		JLabel lblChooseScoreCalculator = new JLabel("Choose Score Calculator:");
		lblChooseScoreCalculator.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblChooseScoreCalculator.setBounds(50, 197, 235, 16);
		getContentPane().add(lblChooseScoreCalculator);
		
		

	}

}
