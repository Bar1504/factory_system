package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Main;
import model.Van;
import model.VehicleTransportation;

public class FindVanGUI extends JInternalFrame {

	private JMenuBar menuBar;
	public FindVanGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		
		JPanel panel1 = new JPanel();
		panel1.setBounds(465, 70, 469, 369);
		panel1.setLayout(null);
		
		JLabel label2 = new JLabel("Van Information:");
		label2.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label2.setBounds(35, 17, 204, 22);
		panel1.add(label2);
		
		JLabel label3 = new JLabel("License Plate: ");
		label3.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label3.setBounds(35, 65, 175, 16);
		panel1.add(label3);
		
		JLabel label4 = new JLabel("Price: ");
		label4.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label4.setBounds(35, 90, 175, 16);
		panel1.add(label4);
		
		JLabel label5 = new JLabel("Cost Of Manufacturing: ");
		label5.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label5.setBounds(35, 118, 175, 16);
		panel1.add(label5);
		
		JLabel label6 = new JLabel("Color: ");
		label6.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label6.setBounds(35, 146, 204, 16);
		panel1.add(label6);
		
		JLabel label7 = new JLabel("Year Of Manufacture: ");
		label7.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label7.setBounds(35, 174, 204, 16);
		panel1.add(label7);
		
		JLabel label8 = new JLabel("Engine Capacity: ");
		label8.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label8.setBounds(35, 202, 204, 16);
		panel1.add(label8);
		
		JLabel label9 = new JLabel("Pollution Level");
		label9.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label9.setBounds(35, 230, 204, 16);
		panel1.add(label9);
		
		JLabel label10 = new JLabel("Trunk Size: ");
		label10.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label10.setBounds(35, 258, 209, 16);
		panel1.add(label10);
		
		JLabel label11 = new JLabel("Max Weight Carrying: ");
		label11.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label11.setBounds(35, 286, 204, 22);
		panel1.add(label11);
		
		JLabel label1 = new JLabel("Find Van By License Plate");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 273, 37);
		getContentPane().add(label1);
		panel1.setVisible(false);
		getContentPane().add(panel1);
		
		JLabel label12 = new JLabel("New label");
		label12.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label12.setBounds(228, 66, 175, 16);
		panel1.add(label12);
		
		JLabel label13 = new JLabel("New label");
		label13.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label13.setBounds(228, 91, 175, 16);
		panel1.add(label13);
		
		JLabel label14 = new JLabel("New label");
		label14.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label14.setBounds(228, 119, 175, 16);
		panel1.add(label14);
		
		JLabel label15 = new JLabel("New label");
		label15.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label15.setBounds(228, 147, 175, 16);
		panel1.add(label15);
		
		JLabel label16 = new JLabel("New label");
		label16.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label16.setBounds(228, 174, 175, 16);
		panel1.add(label16);
		
		JLabel label17 = new JLabel("New label");
		label17.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label17.setBounds(228, 202, 175, 16);
		panel1.add(label17);
		
		JLabel label18 = new JLabel("New label");
		label18.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label18.setBounds(228, 230, 175, 16);
		panel1.add(label18);
		
		JLabel label19 = new JLabel("New label");
		label19.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label19.setBounds(228, 258, 175, 16);
		panel1.add(label19);
		
		JLabel label20 = new JLabel("New label");
		label20.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label20.setBounds(228, 286, 175, 16);
		panel1.add(label20);
		
		JLabel label23 = new JLabel("Profit:");
		label23.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label23.setBounds(35, 320, 204, 16);
		panel1.add(label23);
		
		JLabel label24 = new JLabel("New label");
		label24.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label24.setBounds(228, 320, 204, 16);
		panel1.add(label24);
		

		JComboBox<String> comboBox = new JComboBox<String>();
		
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			if(comboBox.getSelectedIndex() != 0)
			{
				Van v = (Van) Main.libr.getAllVehicleTransportation().get(comboBox.getSelectedItem());
				
				label12.setText(v.getLicensePlate());
				label13.setText(v.getPrice() + "");
				label14.setText(v.getCostOfManufacturing() + "");
				label15.setText(v.getColor()+ "");
				label16.setText(v.getYearOfManufacture()+ "");
				label17.setText(v.getEngineCapacity()+ "");
				label18.setText(v.getPollutionLevel()+ "");
				label19.setText(v.getTrunkSize()+ "");
				label20.setText(v.getMaxWeightCarrying() +"");
				label24.setText(String.valueOf(Main.libr.profitPerVehiclesTransportation(v)));
				panel1.setVisible(true);

			}
			}
		});
		
		comboBox.setBounds(50, 130, 177, 37);
		getContentPane().add(comboBox);
		comboBox.addItem("License Plates:");
		for(VehicleTransportation v: Main.libr.getAllVehicleTransportation().values())
		{
			if(v instanceof Van)
				comboBox.addItem(v.getLicensePlate());
		}

	}

}
