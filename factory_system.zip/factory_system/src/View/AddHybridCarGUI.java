package View;

import java.awt.EventQueue;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.border.EmptyBorder;

import Exceptions.FieldMustBePositiveNumberException;
import Exceptions.IncorrectNumberOfSeats;
import Exceptions.PoullutionLevelHybridVehiclesMustBeOne;
import Exceptions.YearOfManufacturingNotInRangeException;
import model.HybridCar;
import model.Main;
import model.VehicleTransportation;
import utils.Color;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;

public class AddHybridCarGUI extends JInternalFrame {

	private JMenuBar menuBar;
	private JTextField priceField;
	private JTextField costField;
	private JTextField yearField;
	private JTextField engineField;
	private JTextField pollutionField;
	private JTextField seatsField;
	private JComboBox comboBox;
	private Boolean isConvertible;
	private JLabel colorLabel;
	public AddHybridCarGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Fill All The Fields To Add  A New Hybrid Car To The Factory");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel.setBounds(50, 80, 595, 16);
		getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(50, 130, 196, 393);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel priceLabel = new JLabel("Price");
		priceLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		priceLabel.setBounds(0, 0, 144, 16);
		panel.add(priceLabel);
		
		JLabel costLabel = new JLabel("Cost Of Manufacturing");
		costLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		costLabel.setBounds(0, 40, 185, 25);
		panel.add(costLabel);
		
		colorLabel = new JLabel("Color:");
		colorLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		colorLabel.setBounds(0, 80, 144, 16);
		panel.add(colorLabel);
		
		JLabel yearLabel = new JLabel("Year Of Manufacturing: ");
		yearLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		yearLabel.setBounds(0, 120, 202, 16);
		panel.add(yearLabel);
		
		JLabel engineLabel = new JLabel("Engine Capacity:");
		engineLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		engineLabel.setBounds(0, 160, 144, 16);
		panel.add(engineLabel);
		
		JLabel pollutionLabel = new JLabel("Pollution Level:");
		pollutionLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		pollutionLabel.setBounds(0, 200, 144, 16);
		panel.add(pollutionLabel);
		
		JLabel seatsLabel = new JLabel("Number Of Seats:");
		seatsLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		seatsLabel.setBounds(0, 240, 144, 16);
		panel.add(seatsLabel);
		
		JLabel convertibleLabel = new JLabel("Is Convertible");
		convertibleLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		convertibleLabel.setBounds(0, 280, 144, 16);
		panel.add(convertibleLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(246, 108, 223, 415);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		priceField = new JTextField();
		priceField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinputOrDot(e, priceField);
			}
		});
		priceField.setBounds(0, 10, 222, 35);
		panel_1.add(priceField);
		priceField.setColumns(10);
		
		costField = new JTextField();
		costField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinputOrDot(e, costField);
			}
		});
		costField.setColumns(10);
		costField.setBounds(0, 55, 222, 35);
		panel_1.add(costField);
		
		yearField = new JTextField();
		yearField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, yearField);
			}
		});
		yearField.setColumns(10);
		yearField.setBounds(0, 135, 222, 35);
		panel_1.add(yearField);
		
		engineField = new JTextField();
		engineField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinputOrDot(e, engineField);

			}
		});
		engineField.setColumns(10);
		engineField.setBounds(0, 175, 222, 35);
		panel_1.add(engineField);
		
		pollutionField = new JTextField();
		pollutionField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, pollutionField);

			}
		});
		pollutionField.setColumns(10);
		pollutionField.setBounds(0, 215, 222, 35);
		panel_1.add(pollutionField);
		comboBox = new JComboBox<String>();
		comboBox.setBounds(0, 96, 222, 35);
		panel_1.add(comboBox);
		comboBox.addItem("Colors");
		for(Color c: Color.values())
		{
			comboBox.addItem(c.name());
		}
		ButtonGroup group = new ButtonGroup();
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Yes");
		rdbtnNewRadioButton.setBounds(0, 300, 141, 23);
		panel_1.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				isConvertible = true;
			}
		});
		group.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("No");
		rdbtnNewRadioButton_1.setBounds(82, 300, 141, 23);
		panel_1.add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				isConvertible = false;
			}
		});
		group.add(rdbtnNewRadioButton_1);
		
		seatsField = new JTextField();
		seatsField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, seatsField);

			}
		});
		seatsField.setColumns(10);
		seatsField.setBounds(0, 255, 222, 35);
		panel_1.add(seatsField);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox.getSelectedIndex() ==0)
					JOptionPane.showMessageDialog(null, "Select Color");
				else if(priceLabel.getText().isEmpty() || costLabel.getText().isEmpty() || yearLabel.getText().isEmpty() || engineLabel.getText().isEmpty() || pollutionLabel.getText().isEmpty()
						|| seatsLabel.getText().isEmpty() || group.getSelection() == null)
					JOptionPane.showMessageDialog(null, "Fill All Fields");
				else
				{
					int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to add hybrid car to the database?", "", JOptionPane.YES_NO_OPTION);
					if (reply == JOptionPane.YES_OPTION) 
					{
						double price = 0, cost = 0, engine = 0;
						try {
						price = Double.parseDouble(priceField.getText());
						cost = Double.parseDouble(costField.getText());
						engine = Double.parseDouble(engineField.getText());
						}
						catch(Exception e3){
						}

						Color color = Color.valueOf((String) comboBox.getSelectedItem());
						HybridCar hybridCar = new HybridCar(Double.parseDouble(priceField.getText()), Double.parseDouble(costField.getText()), color, Integer.parseInt(yearField.getText()), 
								Double.parseDouble(engineField.getText()), Integer.parseInt(pollutionField.getText()), Integer.parseInt(seatsField.getText()), isConvertible);
						try {
							Main.libr.addHybridCar(hybridCar);
							priceField.setText("");
							costField.setText("");
							yearField.setText("");
							engineField.setText("");
							pollutionField.setText("");
							seatsField.setText("");
							comboBox.setSelectedIndex(0);
							group.clearSelection();
							try {
								Main.libr.setVehicleCounter(Main.libr.getVehicleCounter()+1);
								Main.save();
								JOptionPane.showMessageDialog(null,"Hybrid car added succefully");
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						} catch ( PoullutionLevelHybridVehiclesMustBeOne| IncorrectNumberOfSeats | FieldMustBePositiveNumberException | YearOfManufacturingNotInRangeException e1) {
							VehicleTransportation.setCounter(VehicleTransportation.getCounter()-1);
							JOptionPane.showMessageDialog(null, e1.getMessage());
						
						}
					}
				}
			}
		});
		btnNewButton.setBounds(750, 520, 117, 44);
		getContentPane().add(btnNewButton);
		
	}
	
}
