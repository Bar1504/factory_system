package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.border.EmptyBorder;

import model.Department;
import model.Main;

import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.awt.event.ActionEvent;

public class AppointmentOfNewDepManagerGUI extends JInternalFrame {

	JMenuBar menuBar;
	public AppointmentOfNewDepManagerGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		

		JLabel label1 = new JLabel("Choose Department To Appoint New Manager");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 525, 37);
		getContentPane().add(label1);
		
		JComboBox<String> comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox.getSelectedIndex()!=0)
				{
					try {
						if(Main.libr.appointmentOfNewDepartmentManager(Main.libr.getAllDepartments().get(comboBox.getSelectedIndex())))
							JOptionPane.showMessageDialog(null, "New manager appointed successfully");
						else
							JOptionPane.showMessageDialog(null, "Appointment of new manager failed");
					} catch (HeadlessException | ParseException e1) {
						JOptionPane.showMessageDialog(null, "Appointment of new manager failed");

					}

				}
			}
		});
		comboBox.setBounds(50, 139, 174, 27);
		getContentPane().add(comboBox);
		comboBox.addItem("Departments");
		for(Department d: Main.libr.getAllDepartments().values())
		{
			comboBox.addItem(String.valueOf(d.getDepartmentID()));
		}
		
	}
}
