package View;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.border.EmptyBorder;

import model.Main;

public class IDOfDealWithMinAvgPollutionLevelGUI extends JInternalFrame {

	private JMenuBar menuBar;
	public IDOfDealWithMinAvgPollutionLevelGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		

		JLabel label1 = new JLabel("ID Of Deal With Minimum Average Pollution Level:");
		label1.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
		label1.setBounds(50, 80, 542, 37);
		getContentPane().add(label1);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel.setBounds(50, 151, 169, 31);
		getContentPane().add(lblNewLabel);
		lblNewLabel.setText("Deal " + Main.libr.idOfDealWithMinAvgPollutionLevel());
		
	}

}
