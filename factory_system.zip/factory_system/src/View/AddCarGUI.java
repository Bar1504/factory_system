package View;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.border.EmptyBorder;

import Exceptions.FieldMustBePositiveNumberException;
import Exceptions.IncorrectNumberOfSeats;
import Exceptions.PoullutionLevelNotInRange;
import Exceptions.YearOfManufacturingNotInRangeException;
import model.Car;
import model.Main;
import model.VehicleTransportation;
import utils.Color;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;

import javax.swing.JComboBox;

public class AddCarGUI extends JInternalFrame {

	private JMenuBar menuBar;
	private JTextField priceField;
	private JTextField costField;
	private JTextField yearField;
	private JTextField engineField;
	private JTextField pollutionField;
	private JTextField seatsField;
	private Boolean isConvertible;
	private JComboBox<String> comboBox;
	public AddCarGUI(JMenuBar menuBar) {
		this.menuBar = menuBar;
		setBounds(0, 0, 950, 600);
		setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().add(menuBar);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Fill The Fields to Add a New Car To The Factory");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel.setBounds(50, 80, 514, 35);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1_1 = new JLabel("Price:");
		lblNewLabel_1_1.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel_1_1.setBounds(67, 200, 115, 16);
		getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Cost Of Manufacturing:");
		lblNewLabel_1_2.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel_1_2.setBounds(67, 239, 192, 16);
		getContentPane().add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Color: ");
		lblNewLabel_1_3.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel_1_3.setBounds(67, 278, 115, 16);
		getContentPane().add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Year Of Manufacturing: ");
		lblNewLabel_1_4.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel_1_4.setBounds(67, 318, 192, 16);
		getContentPane().add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Engine Capacity: ");
		lblNewLabel_1_5.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel_1_5.setBounds(67, 358, 192, 16);
		getContentPane().add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Pollution Level: ");
		lblNewLabel_1_6.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel_1_6.setBounds(67, 398, 192, 16);
		getContentPane().add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("Number Of Seats: ");
		lblNewLabel_1_7.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel_1_7.setBounds(67, 438, 159, 16);
		getContentPane().add(lblNewLabel_1_7);
		
		JLabel lblNewLabel_1_8 = new JLabel("Is Convertible: ");
		lblNewLabel_1_8.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel_1_8.setBounds(67, 478, 159, 16);
		getContentPane().add(lblNewLabel_1_8);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Yes");
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				isConvertible = true;
			}
		});		
		rdbtnNewRadioButton.setBounds(271, 475, 141, 23);
		getContentPane().add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("No");
		rdbtnNewRadioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				isConvertible = false;
			}
		});
		rdbtnNewRadioButton_1.setBounds(409, 475, 141, 23);
		getContentPane().add(rdbtnNewRadioButton_1);
		ButtonGroup group = new ButtonGroup();
		group.add(rdbtnNewRadioButton);
		group.add(rdbtnNewRadioButton_1);
		
		priceField = new JTextField();
		priceField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent ke) {
				Main.libr.getOnlyNumbersAsinputOrDot(ke, priceField);
			}
		});
		priceField.setColumns(10);
		priceField.setBounds(271, 192, 222, 35);
		getContentPane().add(priceField);
		
		costField = new JTextField();
		costField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinputOrDot(e, costField);
			}
		});
		costField.setColumns(10);
		costField.setBounds(271, 235, 222, 35);
		getContentPane().add(costField);
		
		yearField = new JTextField();
		yearField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, yearField);
			}
		});
		yearField.setColumns(10);
		yearField.setBounds(271, 314, 222, 35);
		getContentPane().add(yearField);
		
		engineField = new JTextField();
		engineField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinputOrDot(e, engineField);

			}
		});
		engineField.setColumns(10);
		engineField.setBounds(271, 354, 222, 35);
		getContentPane().add(engineField);
		
		pollutionField = new JTextField();
		pollutionField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, pollutionField);

			}
		});
		pollutionField.setColumns(10);
		pollutionField.setBounds(271, 394, 222, 35);
		getContentPane().add(pollutionField);
		
		seatsField = new JTextField();
		seatsField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Main.libr.getOnlyNumbersAsinput(e, seatsField);

			}
		});
		seatsField.setColumns(10);
		seatsField.setBounds(271, 434, 222, 35);
		getContentPane().add(seatsField);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(comboBox.getSelectedIndex() ==0)
					JOptionPane.showMessageDialog(null, "Select Color");
				else if(priceField.getText().isEmpty() || costField.getText().isEmpty() || yearField.getText().isEmpty() || engineField.getText().isEmpty() || pollutionField.getText().isEmpty()
						|| seatsField.getText().isEmpty() || group.getSelection() == null)
					JOptionPane.showMessageDialog(null, "Fill All Fields");
				
				else
				{
					int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to add car to the factory?", "", JOptionPane.YES_NO_OPTION);
					if (reply == JOptionPane.YES_OPTION) 
					{
						double price = 0, cost = 0, engine = 0;
						try {
						price = Double.parseDouble(priceField.getText());
						cost = Double.parseDouble(costField.getText());
						engine = Double.parseDouble(engineField.getText());
						}
						catch(Exception e3){
				}
						Color color = Color.valueOf((String) comboBox.getSelectedItem());
						Car car = new Car(price, cost, color, Integer.parseInt(yearField.getText()), 
								engine, Integer.parseInt(pollutionField.getText()), Integer.parseInt(seatsField.getText()), isConvertible );
						try {
							Main.libr.addCar(car);
							priceField.setText("");
							costField.setText("");
							yearField.setText("");
							engineField.setText("");
							pollutionField.setText("");
							seatsField.setText("");
							comboBox.setSelectedIndex(0);
							group.clearSelection();
							try {
								Main.libr.setVehicleCounter(Main.libr.getVehicleCounter()+1);
								Main.save();
								JOptionPane.showMessageDialog(null, car.getLicensePlate() + " added succefully");

							} catch (IOException e2) {
								e2.printStackTrace();
							}
							
						} catch (PoullutionLevelNotInRange | IncorrectNumberOfSeats | FieldMustBePositiveNumberException  | YearOfManufacturingNotInRangeException e1) {
							// TODO Auto-generated catch block
							VehicleTransportation.setCounter(VehicleTransportation.getCounter()-1);
							JOptionPane.showMessageDialog(null, e1.getMessage());
						}
					}
				}
			}
		});
		btnNewButton.setBounds(753, 480, 135, 46);
		getContentPane().add(btnNewButton);
		
		comboBox = new JComboBox<String>();
		comboBox.setBounds(271, 275, 222, 27);
		comboBox.addItem("Colors");
		for(Color c: Color.values())
		{
			comboBox.addItem(c.name());
		}
		getContentPane().add(comboBox);
		

	}
	
}
