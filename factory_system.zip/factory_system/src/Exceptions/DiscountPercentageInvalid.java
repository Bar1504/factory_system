package Exceptions;

public class DiscountPercentageInvalid extends Exception {
	public DiscountPercentageInvalid(String field)
	{
		super(field + " must be between 0 and 1");
	}

}
