package Exceptions;

public class PasswordLengthException extends Exception {
	public PasswordLengthException()
	{
		super("Password must be at least 8 characters");
		
	}
}
