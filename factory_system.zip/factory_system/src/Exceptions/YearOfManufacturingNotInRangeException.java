package Exceptions;

public class YearOfManufacturingNotInRangeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public YearOfManufacturingNotInRangeException(String s)
	{
		super("Year Of Manufacturing must be between 1900 and 2022. " + s + " not added.");
	}

}
