package Exceptions;

public class DateInvalidException extends Exception {
	public DateInvalidException(String field)
	{
		super(field + " must be before current date");
	}
}
