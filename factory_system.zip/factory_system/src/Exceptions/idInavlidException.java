package Exceptions;

public class idInavlidException extends Exception {
	public idInavlidException()
	{
		super("id must be 9 digits");
	}
}
