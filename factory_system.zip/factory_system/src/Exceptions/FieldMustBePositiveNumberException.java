package Exceptions;

import javax.swing.JLabel;

public class FieldMustBePositiveNumberException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public FieldMustBePositiveNumberException(String field)
	{
		super(field + " Must be positive number");
	}

}
