package Exceptions;

public class PhoneNumberInvalidException extends Exception {
	public PhoneNumberInvalidException()
	{
		super("Phone number must be 10 digits");
	}
}
