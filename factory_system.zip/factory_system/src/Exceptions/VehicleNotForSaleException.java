package Exceptions;

import model.VehicleTransportation;

public class VehicleNotForSaleException extends Exception {
	public VehicleNotForSaleException(VehicleTransportation v)
	{
		super(v.getLicensePlate() + " not for sale");
	}
}
