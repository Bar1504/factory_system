package Exceptions;

public class DepartmentAlreadyExistsException extends Exception {
	public DepartmentAlreadyExistsException(int id)
	{
		super("Department " + id + " already exists. Department not added to the system.");
	}

}
