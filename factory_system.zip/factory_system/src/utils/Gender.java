package utils;

public enum Gender {
	
	M,F

}
