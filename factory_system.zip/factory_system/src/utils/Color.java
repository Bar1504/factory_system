package utils;

public enum Color {
	
	White, Black, Green, Blue, Red, Gold, Silver ,Gray 
} 
