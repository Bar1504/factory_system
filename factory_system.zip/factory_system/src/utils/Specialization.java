package utils;

public enum Specialization {
	
	Finance ,production ,Logistics ,Administration ,costumerService

}
