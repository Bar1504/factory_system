package model;

import java.awt.event.KeyEvent;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Stack;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Exceptions.DateInvalidException;
import Exceptions.DepartmentAlreadyExistsException;
import Exceptions.DiscountPercentageInvalid;
import Exceptions.FieldMustBePositiveNumberException;
import Exceptions.IncorrectNumberOfSeats;
import Exceptions.PasswordLengthException;
import Exceptions.PersonAlreadyExistException;
import Exceptions.PersonNotExistException;
import Exceptions.PhoneNumberInvalidException;
import Exceptions.PoullutionLevelHybridVehiclesMustBeOne;
import Exceptions.PoullutionLevelNotInRange;
import Exceptions.VehicleNotForSaleException;
import Exceptions.YearOfBirthNotInRange;
import Exceptions.YearOfManufacturingNotInRangeException;
import Exceptions.idInavlidException;
import utils.Area;
import utils.Color;
import utils.Gender;	


public class Factory implements Serializable {

	private HashMap<String,VehicleTransportation> vehiclesForSale;
	private HashMap<String,Employee> allEmployees;
	private HashMap<String,Customer> allCustomers;
	private HashMap<String,VehicleTransportation> allVehicleTransportation;
	private HashMap<String,Deal> allDeals;
	private HashMap<Integer,Department> allDepartments;
	private int vehicleCounter = 0;
	private int dealCounter = 0;

	private static Factory factory;
	public int getVehicleCounter() {
		return vehicleCounter;
	}

	public void setVehicleCounter(int vehicleCounter) {
		this.vehicleCounter = vehicleCounter;
	}

	public int getDealCounter() {
		return dealCounter;
	}

	public void setDealCounter(int dealCounter) {
		this.dealCounter = dealCounter;
	}

	private Factory() {
		allEmployees = new HashMap<String,Employee>();
		allCustomers = new HashMap<String, Customer>();
		allVehicleTransportation = new HashMap<String, VehicleTransportation>();
		allDeals = new HashMap<String, Deal>();
		allDepartments = new HashMap<Integer, Department>();
		vehiclesForSale = new HashMap<String, VehicleTransportation>();
	}

	public static Factory getInstance() {
		if(factory == null)
			factory = new Factory();
		return factory; 
	}

	public boolean addEmployee(Employee e) throws PersonAlreadyExistException, YearOfBirthNotInRange, PhoneNumberInvalidException, idInavlidException, DateInvalidException, FieldMustBePositiveNumberException, PasswordLengthException {
		if(e == null) {
			return false;

		}
		if(allEmployees.containsKey(e.getID()))
			throw new PersonAlreadyExistException(e);
		if(e.getYearOfBirth()<1900 ||e.getYearOfBirth()>2022 )
			throw new YearOfBirthNotInRange(e.getID());
		if(e.getPhoneNumber().length()!=10)
			throw new PhoneNumberInvalidException();
		if(e.getID().length()!=9)
			throw new idInavlidException();
		if(e.getDateOfStartWork().after(new Date()))
			throw new DateInvalidException("Date of start work");
		if(e.getSalary()<=0)
			throw new FieldMustBePositiveNumberException("Salary");
		if(e.getPassword().length()<8)
			throw new PasswordLengthException();
		allEmployees.put(e.getID(), e);
		return e.getDep().getAllEmployees().add(e);

	}
	public HashMap<String, VehicleTransportation> getVehiclesForSale() {
		return vehiclesForSale;
	}

	public void setVehiclesForSale(HashMap<String, VehicleTransportation> vehiclesForSale) {
		this.vehiclesForSale = vehiclesForSale;
	}

	public boolean addDepartmentManager(DepartmentManager dm) throws PersonAlreadyExistException, YearOfBirthNotInRange, PhoneNumberInvalidException, idInavlidException, DateInvalidException, FieldMustBePositiveNumberException, PasswordLengthException {
		if(dm == null )
			return false;
		if(allEmployees.containsKey(dm.getID()))
			throw new PersonAlreadyExistException(dm);
		if(dm.getYearOfBirth()<1900 ||dm.getYearOfBirth()>2022 )
			throw new YearOfBirthNotInRange(dm.getID());
		if(dm.getPhoneNumber().length()!=10)
			throw new PhoneNumberInvalidException();
		if(dm.getID().length()!=9)
			throw new idInavlidException();
		if(dm.getDateOfStartWork().after(new Date()))
			throw new DateInvalidException("Date of start work");
		if(dm.getSalary()<=0)
			throw new FieldMustBePositiveNumberException("Salary");
		if(dm.getAppointmentDate().after(new Date()))
			throw new DateInvalidException("Appointment date");
		if(dm.getBonus()<=0)
			throw new FieldMustBePositiveNumberException("Bonus");
		if(dm.getPassword().length() < 8)
			throw new PasswordLengthException();
		allEmployees.put(dm.getID(), dm);
		dm.getDep().setDepManager(dm);
		return true;
	}
	public boolean addCustomer(Customer c) throws PersonAlreadyExistException, YearOfBirthNotInRange, PhoneNumberInvalidException, idInavlidException, DateInvalidException {
		if(c == null)
			return false;
		if(allCustomers.containsKey(c.getID()))
			throw new PersonAlreadyExistException(c);
		if(c.getPhoneNumber().length()!=10)
			throw new PhoneNumberInvalidException();
		if(c.getID().length()!=9)
			throw new idInavlidException();
		if(c.getYearOfBirth()<1900 ||c.getYearOfBirth()>2022 )
			throw new YearOfBirthNotInRange(c.getID());
		if(c.getDateOfJoining().after(new Date()))
			throw new DateInvalidException("Date of joining");
		allCustomers.put(c.getID(), c);
		return true;

	}
	public boolean addVIPCustomer(VIPCustomer vc) throws PersonAlreadyExistException, YearOfBirthNotInRange, PhoneNumberInvalidException, idInavlidException, DateInvalidException, DiscountPercentageInvalid {
		if(vc == null)
			return false;
		if(allCustomers.containsKey(vc.getID()))
			throw new PersonAlreadyExistException(vc);
		if(vc.getYearOfBirth()<1900 ||vc.getYearOfBirth()>2022 )
			throw new YearOfBirthNotInRange(vc.getID());
		if(vc.getPhoneNumber().length()!=10)
			throw new PhoneNumberInvalidException();
		if(vc.getID().length()!=9)
			throw new idInavlidException();
		if(vc.getDateOfJoining().after(new Date()))
		throw new DateInvalidException("Date of joining");
		if(vc.getDiscountPercentage()<= 0 || vc.getDiscountPercentage()>=1)
			throw new DiscountPercentageInvalid("Discount Percentage");
		allCustomers.put(vc.getID(), vc);
		return true;

	}
	public boolean addCar(Car c) throws PoullutionLevelNotInRange, IncorrectNumberOfSeats, FieldMustBePositiveNumberException, YearOfManufacturingNotInRangeException {
		if(c == null)
			return false;
		if(c.getPollutionLevel()>15 |c.getPollutionLevel()<1 )
			throw new PoullutionLevelNotInRange(c.getLicensePlate());
		if(c.getNumberOfSeats()>7)
			throw new IncorrectNumberOfSeats(c.getLicensePlate());
		if(! (c.getPrice()>0))
			throw new FieldMustBePositiveNumberException("Price");
		
		if(c.getYearOfManufacture()< 1900 || c.getYearOfManufacture() > 2022)
			throw new YearOfManufacturingNotInRangeException(c.getLicensePlate());
		if(c.getEngineCapacity()<=0)
			throw new FieldMustBePositiveNumberException("Engine capacity");
		allVehicleTransportation.put(c.getLicensePlate(), c);
		vehiclesForSale.put(c.getLicensePlate(), c);

		return true; 


	};
	public boolean addHybridCar(HybridCar hybridCar) throws  IncorrectNumberOfSeats, PoullutionLevelHybridVehiclesMustBeOne, FieldMustBePositiveNumberException, YearOfManufacturingNotInRangeException       {
		if(hybridCar == null)
			return false;
		if(hybridCar.getPollutionLevel()!=1  )
			throw new PoullutionLevelHybridVehiclesMustBeOne(hybridCar.getLicensePlate());
		if(hybridCar.getNumberOfSeats()>7)
			throw new IncorrectNumberOfSeats(hybridCar.getLicensePlate());
		if(! (hybridCar.getPrice()>0))
			throw new FieldMustBePositiveNumberException("Price");
		
		if(hybridCar.getYearOfManufacture()< 1900 || hybridCar.getYearOfManufacture() > 2022)
			throw new YearOfManufacturingNotInRangeException(hybridCar.getLicensePlate());
		if(hybridCar.getEngineCapacity()<=0)
			throw new FieldMustBePositiveNumberException("Engine capacity");
		allVehicleTransportation.put(hybridCar.getLicensePlate(), hybridCar);
		vehiclesForSale.put(hybridCar.getLicensePlate(), hybridCar);

		return true; 


	}
	public boolean addVan(Van v) throws PoullutionLevelNotInRange, FieldMustBePositiveNumberException {
		if(v == null)
			return false;
		if(v.getPollutionLevel()>15 |v.getPollutionLevel()<1 )
			throw new PoullutionLevelNotInRange(v.getLicensePlate());
		if(v.getTrunkSize()<=0)
			throw new FieldMustBePositiveNumberException("Trunk size");
		allVehicleTransportation.put(v.getLicensePlate(), v);
		vehiclesForSale.put(v.getLicensePlate(), v);

		return true;

	}
	public boolean addMotorcycle(Motorcycle m) throws PoullutionLevelNotInRange, FieldMustBePositiveNumberException, YearOfManufacturingNotInRangeException {
		if(m == null)
			return false;
		if(m.getPollutionLevel()>15 |m.getPollutionLevel()<1 )
			throw new PoullutionLevelNotInRange(m.getLicensePlate());
		if(! (m.getPrice()>0))
			throw new FieldMustBePositiveNumberException("Price");
		if(m.getYearOfManufacture()< 1900 || m.getYearOfManufacture() > 2022)
			throw new YearOfManufacturingNotInRangeException(m.getLicensePlate());
		if(m.getEngineCapacity()<=0)
			throw new FieldMustBePositiveNumberException("Engine capacity");
		allVehicleTransportation.put(m.getLicensePlate(), m);
		vehiclesForSale.put(m.getLicensePlate(), m);
		return true;
	}
	public boolean addHybridMotorcycle(HybridMotorcycle hybridMotorcycle) throws  PoullutionLevelHybridVehiclesMustBeOne, FieldMustBePositiveNumberException, YearOfManufacturingNotInRangeException {
		if(hybridMotorcycle == null)
			return false;
		if(hybridMotorcycle.getPollutionLevel()!=1 )
			throw new PoullutionLevelHybridVehiclesMustBeOne(hybridMotorcycle.getLicensePlate());
		if(! (hybridMotorcycle.getPrice()>0))
			throw new FieldMustBePositiveNumberException("Price");
		
		if(hybridMotorcycle.getYearOfManufacture()< 1900 || hybridMotorcycle.getYearOfManufacture() > 2022)
			throw new YearOfManufacturingNotInRangeException(hybridMotorcycle.getLicensePlate());
		if(hybridMotorcycle.getEngineCapacity()<=0)
			throw new FieldMustBePositiveNumberException("Engine capacity");
		allVehicleTransportation.put(hybridMotorcycle.getLicensePlate(), hybridMotorcycle);
		vehiclesForSale.put(hybridMotorcycle.getLicensePlate(), hybridMotorcycle);

		return true;
	}
	public boolean addDepartment(Department d) throws DepartmentAlreadyExistsException {
		if(d ==null)
			return false;
		if(allDepartments.containsKey(d.getDepartmentID()))
			throw new DepartmentAlreadyExistsException(d.getDepartmentID());
		allDepartments.put(d.getDepartmentID(), d);
		return true;
	} 
	public boolean addDeal(Deal d) throws DateInvalidException, FieldMustBePositiveNumberException, VehicleNotForSaleException {
		if(d == null) {
			return false;
		}
		if(d.getDealDate().after(new Date()))
			throw new DateInvalidException("Deal date");
		if(d.getShippingCost() <= 0)
			throw new FieldMustBePositiveNumberException("Shipping cost");
		for(VehicleTransportation v : d.getAllVehicleTransportation())
		{
			if(!vehiclesForSale.containsKey(v.getLicensePlate()))
				throw new VehicleNotForSaleException(v);
			vehiclesForSale.remove(v.getLicensePlate());
		}
		d.getCustomer().getAllDeals().add(d);
		allDeals.put(d.getDealID(), d);
		
		return true;
	}


	public boolean removeCar(Car car){
		if(car == null)
			return false;
		if(!allVehicleTransportation.containsKey(car.getLicensePlate()))
			return false;
		allVehicleTransportation.remove(car.getLicensePlate());
		if(!vehiclesForSale.containsKey(car.getLicensePlate()))
			return false;
		vehiclesForSale.remove(car.getLicensePlate());

		return true;

	}
	public boolean removeVan(Van van){

		if(van == null)
			return false;
		if(!allVehicleTransportation.containsKey(van.getLicensePlate()))
			return false;
		allVehicleTransportation.remove(van.getLicensePlate());
		if(!vehiclesForSale.containsKey(van.getLicensePlate()))
			return false;
		vehiclesForSale.remove(van.getLicensePlate());

		return true;

	}
	public boolean removeMotorcycle(Motorcycle motorcycle){

		if(motorcycle == null)
			return false;
		if(!allVehicleTransportation.containsKey(motorcycle.getLicensePlate()))
			return false;
		allVehicleTransportation.remove(motorcycle.getLicensePlate());
		if(!vehiclesForSale.containsKey(motorcycle.getLicensePlate()))
			return false;
		vehiclesForSale.remove(motorcycle.getLicensePlate());
		return true;

	}
	public boolean removeHybridCar(HybridCar hybridCar)

	{
		if(hybridCar == null)
			return false;
		if(!allVehicleTransportation.containsKey(hybridCar.getLicensePlate()))
			return false;
		allVehicleTransportation.remove(hybridCar.getLicensePlate());
		if(!vehiclesForSale.containsKey(hybridCar.getLicensePlate()))
			return false;
		vehiclesForSale.remove(hybridCar.getLicensePlate());

		return true;

	}
	public boolean removeHybridMotorcycle(HybridMotorcycle HybridMotorcycle)

	{

		if(HybridMotorcycle == null)
			return false;
		if(!allVehicleTransportation.containsKey(HybridMotorcycle.getLicensePlate()))
			return false;
		allVehicleTransportation.remove(HybridMotorcycle.getLicensePlate());
		if(!vehiclesForSale.containsKey(HybridMotorcycle.getLicensePlate()))
			return false;
		vehiclesForSale.remove(HybridMotorcycle.getLicensePlate());

		return true;

	}

	public boolean removeCustomer(Customer customer) throws PersonNotExistException{
		if(customer == null)
			throw new PersonNotExistException();
		if(!allCustomers.containsKey(customer.getID())||customer == null)
			throw new PersonNotExistException();
		allCustomers.remove(customer.getID());
		return true;

	}
	public boolean removeVIPCustomer(VIPCustomer vipCustomer)throws PersonNotExistException{

		if(vipCustomer == null)
			throw new PersonNotExistException();
		if(!allCustomers.containsKey(vipCustomer.getID()))
			throw new PersonNotExistException();
		allCustomers.remove(vipCustomer.getID());
		return true;
	}
	public boolean removeEmployee(Employee employee)throws PersonNotExistException{

		if(employee == null)
			throw new PersonNotExistException();
		if(!allEmployees.containsKey(employee.getID()))
			throw new PersonNotExistException();
		allEmployees.remove(employee.getID());
		employee.getDep().getAllEmployees().remove(employee);
		return true;

	}
	public boolean removeDepartmentManager(DepartmentManager departmentManager)throws PersonNotExistException{

		if(departmentManager == null)
			throw new PersonNotExistException();
		if(!allEmployees.containsKey(departmentManager.getID()))
			throw new PersonNotExistException();
		allEmployees.remove(departmentManager.getID());
		departmentManager.getDep().setDepManager(null);
		return true;

	}
	public boolean removeDeal(Deal deal){ 

		if(deal == null)
			return false;
		if(!allDeals.containsKey(deal.getDealID()))
			return false;
		for(VehicleTransportation v: deal.getAllVehicleTransportation())
		{
			vehiclesForSale.put(v.getLicensePlate(), v);
		}
		deal.getCustomer().getAllDeals().remove(deal);
		allDeals.remove(deal.getDealID());
		return true;
	}


	public boolean removeDepartment(Department department){

		if(department == null)
			return false;
		if(!allDepartments.containsKey(department.getDepartmentID()))
			return false;
		for(Employee e: department.getAllEmployees()) {
			allEmployees.remove(e.getID());

		}
		if(department.getDepManager()!=null)
			allEmployees.remove(department.getDepManager().getID());
		allDepartments.remove(department.getDepartmentID());
		return true;

	}

	public VehicleTransportation getRealVehicleTransportation(String licensePlate){
		return allVehicleTransportation.get(licensePlate);

	}
	public HybridCar getRealHybridCar(String licensePlate){
		if(allVehicleTransportation.get(licensePlate) != null)
			return (HybridCar)allVehicleTransportation.get(licensePlate);
		return null;
	}
	public HybridMotorcycle getRealHybridMotorcycle(String licensePlate){
		if(allVehicleTransportation.get(licensePlate) != null)
			return (HybridMotorcycle)allVehicleTransportation.get(licensePlate);
		return null;
	}
	public Motorcycle getRealMotorcycle(String licensePlate){
		if(allVehicleTransportation.get(licensePlate) != null)
			return (Motorcycle)allVehicleTransportation.get(licensePlate);
		return null;
	}
	public Car getRealCar(String licensePlate){
		if(allVehicleTransportation.get(licensePlate) != null)
			return (Car)allVehicleTransportation.get(licensePlate);
		return null;
	}
	public Van getRealVan(String licensePlate){
		if(allVehicleTransportation.get(licensePlate) != null)
			return (Van)allVehicleTransportation.get(licensePlate);
		return null;
	}
	public Customer getRealCustomer(String ID){
		if(allCustomers.get(ID) != null)
			return (Customer)allCustomers.get(ID);
		return null;
	}
	public Customer getRealVIPCustomer(String ID){
		if(allCustomers.get(ID) != null)
			return (VIPCustomer)allCustomers.get(ID);
		return null;
	}
	public Employee getRealEmployee(String ID){
		if(allEmployees.get(ID) != null)
			return (Employee)allEmployees.get(ID);
		return null;
	}
	public DepartmentManager getRealDepartmentManager(String ID){
		if(allEmployees.get(ID) != null)
			return (DepartmentManager)allEmployees.get(ID);
		return null;
	}
	public Deal getRealDeal(String dealID){
		return allDeals.get(dealID);
	}
	public Department getRealDepartment(int departmentID){
		return allDepartments.get(departmentID);
	}


	//******************************
	public HashMap<Area,ArrayList<Customer>> customersByArea(){
		HashMap<Area,ArrayList<Customer>> toReturn = new HashMap<Area, ArrayList<Customer>>();
		for(Area a: Area.values()) {
			toReturn.put(a, new ArrayList<Customer>());
		}
		for(Customer c : allCustomers.values()) {
			toReturn.get(c.getArea()).add(c);
		}

		return toReturn;
	}
	public HashMap<Gender, HashMap <Integer, ArrayList<Person>>> personsByGenderAndYearOfBirth()

	{
		HashMap<Gender, HashMap <Integer, ArrayList<Person>>> toReturn = new HashMap<>();
		toReturn.put(Gender.F, new HashMap<>());
		toReturn.put(Gender.M, new HashMap<>());
		for(Person s: allCustomers.values()) {
			if(!toReturn.get(s.getGender()).containsKey(s.getYearOfBirth()))
			{
				toReturn.get(s.getGender()).put(s.getYearOfBirth(), new ArrayList<Person>());
			}
			toReturn.get(s.getGender()).get(s.getYearOfBirth()).add(s);
		}
		for(Person s: allEmployees.values()) {
			if(!toReturn.get(s.getGender()).containsKey(s.getYearOfBirth()))
			{
				toReturn.get(s.getGender()).put(s.getYearOfBirth(), new ArrayList<Person>());
			}
			toReturn.get(s.getGender()).get(s.getYearOfBirth()).add(s);
		}
		return toReturn;

	}
	public HashMap<Color, Integer> countOfVehiclesTransportationByColor(){
		HashMap<Color, Integer> toReturn = new HashMap<Color, Integer>();
		for(Color c : Color.values()) {
			toReturn.put(c, 0);
		}
		for(Deal d : allDeals.values()) {
			for(VehicleTransportation v : d.getAllVehicleTransportation()) {
				if(v != null)
					toReturn.put(v.getColor(), toReturn.get(v.getColor())+1);
			}
		}
		return toReturn;

	}
	public double avgPollutionLevelOfDeal (Deal deal)
	{
		
		if(deal==null)
			return -1;
		//sums the pollution level of all the vehicles in the deal//
		return deal.getAllVehicleTransportation().stream().mapToDouble(v->v.getPollutionLevel()).sum() /deal.getAllVehicleTransportation().size();
		
		//returns the average by returning the sum divided by the amount of vehicles//
		
	}
	// check after the input and the main
	public String idOfDealWithMinAvgPollutionLevel() {
		if(allDeals.isEmpty())
			return("No Deals Has Been Made Yet");
		double minAvg=Double.MAX_VALUE;
		Deal d = allDeals.get("1");
		for(Deal temp : allDeals.values()) {
			if(avgPollutionLevelOfDeal(temp)<=minAvg & temp.getDealID().compareTo(d.getDealID())>0) {
				d = temp;
				minAvg = avgPollutionLevelOfDeal(d);
			} 
		}
		return d.getDealID();
	}
	public double avgPollutionLevelOfAllVehiclesTransportation()
	{
		double sum=0.0;
		for(VehicleTransportation v : allVehicleTransportation.values()) {
			sum += v.getPollutionLevel();
		}
		return (sum/allVehicleTransportation.size());

	}
	public double profitPerVehiclesTransportation (VehicleTransportation vehicleTransportation) {
		if(vehicleTransportation == null)
			return 0;
		return Stream.of(vehicleTransportation).mapToDouble(v-> v.getPrice() - v.getCostOfManufacturing()).sum();
	}

	public boolean isGlobalStandard()
	{
		if(avgPollutionLevelOfAllVehiclesTransportation()<=5) {
			if(relativePrecentageOfHybrid()>=0.4)
				return true;
		}
		return false;
	}
	public double relativePrecentageOfHybrid() {
		int countHybrid =0;
		for(VehicleTransportation v: allVehicleTransportation.values()) {
			if(v instanceof HybridCar || v instanceof HybridMotorcycle)
				countHybrid++;
		}
		return (double)countHybrid/allVehicleTransportation.size();	
	}

	public int howManyHybridVehiclesTransportationNeeded () {
		if(isGlobalStandard()==true) {
			return 0;
		}
		else {
			int countHybridVehicles=0 , countTotalVehicles = allVehicleTransportation.size() ,carsToAdd=0;
			double sumPollutionLevel=0;

			for(VehicleTransportation v: allVehicleTransportation.values()) {
				if(v instanceof HybridCar || v instanceof HybridMotorcycle)
					countHybridVehicles++;
				sumPollutionLevel += v.getPollutionLevel();
			}

			double rpOfHybrid = relativePrecentageOfHybrid();
			double avgPollution = avgPollutionLevelOfAllVehiclesTransportation();

			while( !(rpOfHybrid>=0.4 && avgPollution<=5) ) {
				carsToAdd++;
				sumPollutionLevel++;
				countHybridVehicles++;
				countTotalVehicles++;
				rpOfHybrid = (double)countHybridVehicles/countTotalVehicles;
				avgPollution = sumPollutionLevel / countTotalVehicles;
			}
			return carsToAdd;
		}
	}
	public boolean appointmentOfNewDepartmentManager(Department department) throws ParseException {
		if(department== null || department.getDepManager()!=null)
			return false;
		Date date = new SimpleDateFormat("dd/MM/yyyy").parse("01/06/2025");
		Employee s=null;
		Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse("01/06/2022");
		for(Employee e: department.getAllEmployees()) {

			if(e.getDateOfStartWork().before(date)) {
				date=e.getDateOfStartWork();
				s=e;
			}}
		allEmployees.remove(s.getID());
		DepartmentManager toreturn = new DepartmentManager(s.getID(), s.getFirstName(), s.getLastName(), s.getPhoneNumber(), s.getGender(), s.getDateOfStartWork(), s.getSalary()*1.5, department,s.getYearOfBirth(), date1, 1500, s.getPassword());
		allEmployees.put(toreturn.getID(), toreturn);

		department.setDepManager(toreturn);	
		
		return department.getAllEmployees().remove(s);
	}
	
	public int totalProfit() {
		double totalProfit = allDeals.values().stream().mapToDouble(d -> d.getTotalDealPrice()
				- d.getAllVehicleTransportation().stream().mapToDouble(v -> v.getCostOfManufacturing()).sum()).sum();
		
		return (int) totalProfit;


	}
	public List<Employee> allEmployees(int k)
	{
		
		return getAllEmployees().values().stream().sorted().collect(Collectors.toList()).subList(0, Math.min(k,getAllEmployees().size()));
				
	}
	public ArrayList<Customer> allCustomers(){
		ArrayList<Customer> toReturn = new ArrayList<Customer>(getAllCustomers().values());
		Collections.sort(toReturn);
		return toReturn;
	}
	public HashMap<String, Employee> getAllEmployees() {
		return allEmployees;
	}

	public TreeSet<VehicleTransportation> allVehicleTransportations(){
		TreeSet<VehicleTransportation> toReturn = new TreeSet<>(new VehicleTransportationsCompare() );

		for(VehicleTransportation v : getAllVehicleTransportation().values()) {
			toReturn.add(v);
		}
		return toReturn;
	}
	public TreeSet<Customer> allCustomersCmp(){
		TreeSet<Customer> toReturn = new TreeSet<>(new CustomerComp());

		for(Customer v : getAllCustomers().values()) {
			toReturn.add(v);
		}		
		return toReturn;


	}

	public 	List<Deal> getBestsDeal(int k,ScoreCalculator score)
	{	
		ArrayList<Deal> dealssbest=new ArrayList<Deal>(allDeals.values());
		Collections.sort(dealssbest, new CcomperitemScore(score));//sort by score !!by class comperitemScore(method sort static in class Collections
		if(getAllDeals().size()<=k) {return dealssbest;}
		else return dealssbest.subList(0, k);}// the best  k between index 0 and k (not including)!!!




	 public ArrayList<DepartmentManager> AllBestsDepManger()
	 {
		 return (ArrayList<DepartmentManager>) allEmployees.values().stream().filter(e -> e instanceof DepartmentManager).map(e -> (DepartmentManager) e).sorted(
				 new DepMangerComp()).collect(Collectors.toList());
	 }
	public void setAllEmployees(HashMap<String, Employee> allEmployees) {
		this.allEmployees = allEmployees;
	}

	public HashMap<String, Customer> getAllCustomers() {
		return allCustomers;
	}

	public void setAllCustomers(HashMap<String, Customer> allCustomers) {
		this.allCustomers = allCustomers;
	}

	public HashMap<String, VehicleTransportation> getAllVehicleTransportation() {
		return allVehicleTransportation;
	}

	public void setAllVehicleTransportation(HashMap<String, VehicleTransportation> allVehicleTransportation) {
		this.allVehicleTransportation = allVehicleTransportation;
	}

	public HashMap<String, Deal> getAllDeals() {
		return allDeals;
	}

	public void setAllDeals(HashMap<String, Deal> allDeals) {
		this.allDeals = allDeals;
	}

	public HashMap<Integer, Department> getAllDepartments() {
		return allDepartments;
	}

	public void setAllDepartments(HashMap<Integer, Department> allDepartments) {
		this.allDepartments = allDepartments;
	}

	public static Factory getEnterpise() {
		return factory;
	}
	public static void setEnterpise(Factory enterpise) {
		Factory.factory = enterpise;
	}
	
	public void getOnlyNumbersAsinputOrDot (KeyEvent key, JTextField textField) {
		String value = textField.getText();
        int l = value.length();
        if ((key.getKeyChar() >= '0' && key.getKeyChar() <= '9')|| key.getKeyChar()=='.' || key.getKeyChar()==key.VK_BACK_SPACE) {
           textField.setEditable(true);
        } else {
           textField.setEditable(false);
           JOptionPane.showMessageDialog(null, "Input for this field must include numeric numbers", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
	}
	
	public void getOnlyNumbersAsinput (KeyEvent key, JTextField textField) {
		String value = textField.getText();
        int l = value.length();
        if ((key.getKeyChar() >= '0' && key.getKeyChar() <= '9') || key.getKeyChar()==key.VK_BACK_SPACE ) {
           textField.setEditable(true);
        } else {
           textField.setEditable(false);
           JOptionPane.showMessageDialog(null, "Input for this field must include numeric numbers", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
	}
}
