package model;

import java.io.Serializable;
import java.util.Date;

import utils.Gender;

public class Employee extends Person implements Serializable{
	
	private Date dateOfStartWork;
	private Double salary;
	private Department dep;
	private String password;

	public Employee(String iD, String firstName, String lastName, String phoneNumber, Gender gender,
			Date dateOfStartWork, Double salary, Department dep, int yearOfBirth, String password) {
		super(iD, firstName, lastName, phoneNumber, gender,yearOfBirth);
		this.dateOfStartWork = dateOfStartWork;
		this.salary = salary;
		this.dep = dep;
		this.password = password;
	}
	public Date getDateOfStartWork() {
		return dateOfStartWork;
	}
	public void setDateOfStartWork(Date dateOfStartWork) {
		this.dateOfStartWork = dateOfStartWork;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Department getDep() {
		return dep;
	}
	public void setDep(Department dep) {
		this.dep = dep;
	} 
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return super.toString() + ", salary= " + salary  +" Department= " +getDep().getDepartmentID();
	}

	
	
	
	

}
