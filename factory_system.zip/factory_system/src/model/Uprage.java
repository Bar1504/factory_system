package model;

public interface Uprage {
	void upgrade();
}
