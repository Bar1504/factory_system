package model;

public interface Hybrid {
	double setHybridProperty();

}
